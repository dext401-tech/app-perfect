package com.mc.iptv

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Blue = Color(0xFF3B82F6)
private val Green = Color(0xFF10B981)
private val Gray = Color(0xFFB0B0B0)
private val accents = Regex("\\p{Mn}+")

private enum class Mode { NONE, CATEGORIES, CHANNELS, SEARCH, MANAGE, SETTINGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = Color.Black, contentColor = Color.White) {
                    App()
                }
            }
        }
    }
}

private fun downloadAndParse(url: String): List<Channel> {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 15000
    c.readTimeout = 30000
    c.setRequestProperty("User-Agent", "MCTV/1.0")
    return c.inputStream.bufferedReader().use { M3uParser.parse(it) }
}

private fun normalize(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD).replace(accents, "").lowercase(Locale.ROOT)

private fun mergeOrder(saved: String, all: List<String>): List<String> {
    val set = all.toSet()
    val s = saved.split("\n").filter { it in set }
    val seen = s.toSet()
    return s + all.filter { it !in seen }
}

private fun moveItem(list: List<String>, i: Int, d: Int): List<String> {
    val j = i + d
    if (j !in list.indices) return list
    val m = list.toMutableList()
    val t = m[i]; m[i] = m[j]; m[j] = t
    return m
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("mctv", 0) }
    var url by remember { mutableStateOf(prefs.getString("m3u", "") ?: "") }
    var reloadTrigger by remember { mutableIntStateOf(0) }
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    // Estado de actualización OTA desde GitHub
    var githubRepo by remember {
        val saved = prefs.getString("github_repo", "") ?: ""
        mutableStateOf(saved.ifBlank { BuildConfig.GITHUB_REPO })
    }
    var availableUpdate by remember { mutableStateOf<ReleaseInfo?>(null) }
    var downloadingUpdate by remember { mutableStateOf(false) }
    var downloadProgress by remember { mutableIntStateOf(0) }

    // Comprobar actualizaciones automáticamente al abrir la app
    LaunchedEffect(githubRepo) {
        if (githubRepo.isBlank()) return@LaunchedEffect
        runCatching {
            val latest = Updater.checkLatest(githubRepo)
            if (latest != null && Updater.isNewer(latest.tagName, BuildConfig.VERSION_NAME)) {
                availableUpdate = latest
            }
        }
    }

    LaunchedEffect(url, reloadTrigger) {
        if (url.isBlank()) {
            channels = emptyList()
            return@LaunchedEffect
        }
        loading = true
        error = null
        try {
            channels = withContext(Dispatchers.IO) { downloadAndParse(url) }
            if (channels.isEmpty()) error = "La lista no tiene canales"
        } catch (e: Exception) {
            error = e.message ?: "Error al cargar la lista"
        }
        loading = false
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (channels.isEmpty()) {
            SetupScreen(url, loading, error) {
                prefs.edit().putString("m3u", it).apply()
                url = it
                reloadTrigger += 1
            }
        } else {
            PlayerScreen(
                channels = channels,
                prefs = prefs,
                currentUrl = url,
                githubRepo = githubRepo,
                availableUpdate = availableUpdate,
                onSaveUrl = { newUrl ->
                    prefs.edit().putString("m3u", newUrl).apply()
                    url = newUrl
                    reloadTrigger += 1
                },
                onReloadList = { reloadTrigger += 1 },
                onSaveRepo = { newRepo ->
                    val clean = newRepo.trim().removePrefix("https://github.com/").removeSuffix("/")
                    prefs.edit().putString("github_repo", clean).apply()
                    githubRepo = clean
                },
                onTriggerUpdate = { release ->
                    availableUpdate = release
                }
            )
        }

        // Modal de actualización OTA si detecta nueva versión en GitHub
        availableUpdate?.let { rel ->
            UpdateBannerDialog(
                release = rel,
                downloading = downloadingUpdate,
                progress = downloadProgress,
                onInstall = {
                    if (!downloadingUpdate) {
                        downloadingUpdate = true
                        scope.launch {
                            try {
                                Updater.downloadAndInstall(ctx, rel.apkUrl) { p ->
                                    downloadProgress = p
                                }
                            } catch (e: Exception) {
                                Toast.makeText(
                                    ctx,
                                    "Error al descargar actualización: ${e.message}",
                                    Toast.LENGTH_LONG
                                ).show()
                            } finally {
                                downloadingUpdate = false
                            }
                        }
                    }
                },
                onDismiss = { if (!downloadingUpdate) availableUpdate = null }
            )
        }
    }
}

@Composable
private fun UpdateBannerDialog(
    release: ReleaseInfo,
    downloading: Boolean,
    progress: Int,
    onInstall: () -> Unit,
    onDismiss: () -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .width(560.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF1E1E1E))
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Nueva actualización disponible (${release.tagName})",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Versión instalada: v${BuildConfig.VERSION_NAME}",
                fontSize = 16.sp,
                color = Gray
            )
            if (release.notes.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text(release.notes, fontSize = 16.sp, color = Color(0xFFD0D0D0), maxLines = 4)
            }
            Spacer(Modifier.height(24.dp))
            if (downloading) {
                Text("Descargando APK... $progress%", fontSize = 20.sp, color = Green)
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    FocusChip(
                        "Actualizar ahora",
                        modifier = Modifier.focusRequester(focus),
                        activeColor = Green,
                        onClick = onInstall
                    )
                    FocusChip("Más tarde", onClick = onDismiss)
                }
            }
        }
    }
}

@Composable
fun SetupScreen(initial: String, loading: Boolean, error: String?, onLoad: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    Column(
        Modifier.fillMaxSize().padding(80.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("MC TV", fontSize = 40.sp, fontWeight = FontWeight.Bold)
        Text("v${BuildConfig.VERSION_NAME}", fontSize = 16.sp, color = Gray)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("URL de tu lista M3U") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(0.7f)
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onLoad(text.trim()) }, enabled = !loading && text.isNotBlank()) {
            Text(if (loading) "Cargando..." else "Cargar lista")
        }
        error?.let {
            Spacer(Modifier.height(16.dp))
            Text(it, color = Color(0xFFFF6B6B))
        }
    }
}

@Composable
private fun PlayerScreen(
    channels: List<Channel>,
    prefs: SharedPreferences,
    currentUrl: String,
    githubRepo: String,
    availableUpdate: ReleaseInfo?,
    onSaveUrl: (String) -> Unit,
    onReloadList: () -> Unit,
    onSaveRepo: (String) -> Unit,
    onTriggerUpdate: (ReleaseInfo) -> Unit
) {
    val ctx = LocalContext.current
    val player = remember {
        val http = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)
            .setAllowCrossProtocolRedirects(true)
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(20000, 40000, 2500, 5000)
            .build()
        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .setLoadControl(load)
            .build()
    }

    // ---- Categorías: orden y ocultas (se guardan en prefs) ----
    val allGroups = remember(channels) { channels.map { it.group }.distinct() }
    val counts = remember(channels) { channels.groupingBy { it.group }.eachCount() }
    val searchIndex = remember(channels) { channels.map { it to normalize(it.name) } }
    var order by remember(allGroups) {
        mutableStateOf(mergeOrder(prefs.getString("cat_order", "") ?: "", allGroups))
    }
    var hidden by remember(allGroups) {
        mutableStateOf((prefs.getStringSet("cat_hidden", emptySet()) ?: emptySet()).toSet())
    }
    fun saveCategories() {
        prefs.edit()
            .putString("cat_order", order.joinToString("\n"))
            .putStringSet("cat_hidden", hidden.toSet())
            .apply()
    }
    val visible = remember(channels, hidden) {
        channels.filter { it.group !in hidden }.ifEmpty { channels }
    }

    // ---- Reproducción y recuerdo del último canal ----
    var playlist by remember(visible) { mutableStateOf(visible) }
    var index by remember(visible) {
        val lastUrl = prefs.getString("last_channel_url", null)
        val found = if (lastUrl != null) visible.indexOfFirst { it.url == lastUrl } else -1
        mutableIntStateOf(found.coerceAtLeast(0))
    }
    val current = playlist.getOrNull(index) ?: channels.first()

    var mode by remember { mutableStateOf(Mode.NONE) }
    var openGroup by remember { mutableStateOf<String?>(null) }
    var overlay by remember { mutableStateOf(true) }
    var size by remember { mutableStateOf(VideoSize.UNKNOWN) }
    var failures by remember { mutableIntStateOf(0) }
    var buffering by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    val rootFocus = remember { FocusRequester() }

    fun step(d: Int) {
        if (playlist.isEmpty()) return
        index = (index + d + playlist.size) % playlist.size
    }
    fun pick(list: List<Channel>, i: Int) {
        playlist = list
        index = i
        mode = Mode.NONE
    }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) { size = videoSize }
            override fun onPlayerError(error: PlaybackException) { failures += 1 }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) { failures = 0; status = null }
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    LaunchedEffect(current.url) {
        prefs.edit().putString("last_channel_url", current.url).apply()
        size = VideoSize.UNKNOWN
        failures = 0
        status = null
        player.setMediaItem(MediaItem.fromUri(current.url))
        player.prepare()
        player.playWhenReady = true
        overlay = true
    }
    LaunchedEffect(overlay, current.url) {
        if (overlay) { delay(5000); overlay = false }
    }
    LaunchedEffect(mode) {
        if (mode == Mode.NONE) runCatching { rootFocus.requestFocus() }
    }
    LaunchedEffect(failures) {
        if (failures == 0) return@LaunchedEffect
        if (failures > 6) { status = "Sin señal"; return@LaunchedEffect }
        status = "Reconectando... ($failures)"
        delay(minOf(1000L shl (failures - 1), 8000L))
        player.setMediaItem(MediaItem.fromUri(current.url))
        player.prepare()
        player.playWhenReady = true
    }
    LaunchedEffect(buffering, failures, current.url) {
        if (buffering && failures <= 6) { delay(15000); failures += 1 }
    }

    BackHandler(enabled = mode != Mode.NONE || overlay) {
        when (mode) {
            Mode.NONE -> overlay = false
            Mode.CATEGORIES -> mode = Mode.NONE
            else -> mode = Mode.CATEGORIES
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown || mode != Mode.NONE) return@onPreviewKeyEvent false
                when (e.key) {
                    Key.DirectionLeft -> { mode = Mode.CATEGORIES; true }
                    Key.DirectionCenter, Key.Enter -> { overlay = !overlay; true }
                    Key.DirectionUp, Key.ChannelUp -> { step(1); true }
                    Key.DirectionDown, Key.ChannelDown -> { step(-1); true }
                    else -> false
                }
            }
            .focusRequester(rootFocus)
            .focusable()
    ) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    useController = false
                    keepScreenOn = true
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (overlay && mode == Mode.NONE) {
            val res = if (size.height > 0) "${size.width}x${size.height}" else ""
            Clock(Modifier.align(Alignment.TopEnd).padding(24.dp))
            PlayerOverlay(current, res, Modifier.align(Alignment.BottomCenter))
        }

        status?.let { Pill(it, Modifier.align(Alignment.Center), 26.sp) }

        val side = Modifier.align(Alignment.CenterStart)
        when (mode) {
            Mode.NONE -> {}
            Mode.CATEGORIES -> CategoriesPanel(
                modifier = side,
                groups = order.filter { it !in hidden }.map { it to (counts[it] ?: 0) },
                total = visible.size,
                selected = openGroup,
                hasUpdate = availableUpdate != null,
                onAll = { openGroup = null; mode = Mode.CHANNELS },
                onGroup = { openGroup = it; mode = Mode.CHANNELS },
                onSearch = { mode = Mode.SEARCH },
                onManage = { mode = Mode.MANAGE },
                onSettings = { mode = Mode.SETTINGS }
            )
            Mode.CHANNELS -> {
                val g = openGroup
                val list = remember(g, channels, visible) {
                    if (g == null) visible else channels.filter { it.group == g }
                }
                ChannelsPanel(side, g ?: "Todos", list, current) { l, i -> pick(l, i) }
            }
            Mode.SEARCH -> SearchPanel(side, searchIndex, hidden) { l, i -> pick(l, i) }
            Mode.MANAGE -> ManagePanel(
                modifier = side,
                order = order,
                hidden = hidden,
                counts = counts,
                onMove = { i, d -> order = moveItem(order, i, d); saveCategories() },
                onToggle = { g ->
                    hidden = if (g in hidden) hidden - g else hidden + g
                    saveCategories()
                }
            )
            Mode.SETTINGS -> SettingsPanel(
                modifier = side,
                currentUrl = currentUrl,
                githubRepo = githubRepo,
                onSaveUrl = {
                    onSaveUrl(it)
                    mode = Mode.NONE
                },
                onReloadList = {
                    onReloadList()
                    mode = Mode.NONE
                },
                onSaveRepo = onSaveRepo,
                onTriggerUpdate = onTriggerUpdate
            )
        }
    }
}

// ---------------- Paneles ----------------

@Composable
private fun SidePanel(modifier: Modifier, width: Dp, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxHeight()
            .width(width)
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xF5000000), Color(0xD9000000), Color.Transparent)
                )
            )
            .padding(start = 16.dp, end = 48.dp, top = 24.dp, bottom = 16.dp),
        content = content
    )
}

@Composable
private fun CategoriesPanel(
    modifier: Modifier,
    groups: List<Pair<String, Int>>,
    total: Int,
    selected: String?,
    hasUpdate: Boolean,
    onAll: () -> Unit,
    onGroup: (String) -> Unit,
    onSearch: () -> Unit,
    onManage: () -> Unit,
    onSettings: () -> Unit
) {
    val focus = remember { FocusRequester() }
    val selIdx = if (selected == null) 0 else groups.indexOfFirst { it.first == selected } + 1
    val state = rememberLazyListState(initialFirstVisibleItemIndex = selIdx.coerceAtLeast(0))
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    SidePanel(modifier, 620.dp) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(start = 8.dp)) {
            FocusChip("Buscar", onClick = onSearch)
            FocusChip("Categorías", onClick = onManage)
            FocusChip(
                if (hasUpdate) "Ajustes • 1" else "Ajustes",
                activeColor = if (hasUpdate) Green else Blue,
                onClick = onSettings
            )
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(state = state) {
            item {
                CategoryRow(
                    "Todos", total,
                    if (selected == null) Modifier.focusRequester(focus) else Modifier,
                    onAll
                )
            }
            itemsIndexed(groups, key = { _, g -> g.first }) { _, g ->
                CategoryRow(
                    g.first, g.second,
                    if (g.first == selected) Modifier.focusRequester(focus) else Modifier
                ) { onGroup(g.first) }
            }
        }
    }
}

@Composable
private fun SettingsPanel(
    modifier: Modifier,
    currentUrl: String,
    githubRepo: String,
    onSaveUrl: (String) -> Unit,
    onReloadList: () -> Unit,
    onSaveRepo: (String) -> Unit,
    onTriggerUpdate: (ReleaseInfo) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var m3uText by remember { mutableStateOf(currentUrl) }
    var repoText by remember { mutableStateOf(githubRepo) }
    var checkingUpdate by remember { mutableStateOf(false) }
    var updateMsg by remember { mutableStateOf<String?>(null) }
    val focus = remember { FocusRequester() }

    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    SidePanel(modifier, 780.dp) {
        Text("Configuración y Actualizaciones", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
        Text(
            "Versión instalada: v${BuildConfig.VERSION_NAME} (Build ${BuildConfig.VERSION_CODE})",
            fontSize = 16.sp, color = Gray, modifier = Modifier.padding(start = 8.dp, bottom = 16.dp)
        )

        // Sección 1: Lista M3U
        Text("Lista M3U", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = m3uText,
            onValueChange = { m3uText = it },
            singleLine = true,
            label = { Text("URL de tu lista M3U") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(start = 8.dp)) {
            FocusChip(
                "Recargar canales ahora",
                modifier = Modifier.focusRequester(focus),
                onClick = onReloadList
            )
            FocusChip("Guardar nueva URL") {
                if (m3uText.isNotBlank()) onSaveUrl(m3uText.trim())
            }
            FocusChip("Cambiar desde inicio") {
                onSaveUrl("")
            }
        }

        Spacer(Modifier.height(28.dp))

        // Sección 2: Actualización OTA desde GitHub
        Text("Actualización automática (GitHub OTA)", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
        Text(
            "Al hacer push a GitHub se genera un Release firmado y la TV se actualiza sola",
            fontSize = 15.sp, color = Gray, modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
        )
        OutlinedTextField(
            value = repoText,
            onValueChange = { repoText = it },
            singleLine = true,
            label = { Text("Repositorio GitHub (ej: usuario/MCTV)") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(start = 8.dp)) {
            FocusChip(
                if (checkingUpdate) "Buscando..." else "Buscar actualización ahora",
                activeColor = Green
            ) {
                if (checkingUpdate) return@FocusChip
                val clean = repoText.trim().removePrefix("https://github.com/").removeSuffix("/")
                onSaveRepo(clean)
                if (clean.isBlank()) {
                    updateMsg = "Escribe tu usuario/repositorio de GitHub primero"
                    return@FocusChip
                }
                checkingUpdate = true
                updateMsg = "Consultando GitHub Releases..."
                scope.launch {
                    try {
                        val rel = Updater.checkLatest(clean)
                        if (rel == null) {
                            updateMsg = "No se encontró ningún Release con APK en $clean"
                        } else if (Updater.isNewer(rel.tagName, BuildConfig.VERSION_NAME)) {
                            updateMsg = "¡Nueva versión ${rel.tagName} encontrada!"
                            onTriggerUpdate(rel)
                        } else {
                            updateMsg = "Ya tienes la última versión (${rel.tagName}). Reinstalando si pulsas..."
                            onTriggerUpdate(rel)
                        }
                    } catch (e: Exception) {
                        updateMsg = "Error al conectar con GitHub: ${e.message}"
                    } finally {
                        checkingUpdate = false
                    }
                }
            }
            FocusChip("Guardar repo") {
                onSaveRepo(repoText)
                Toast.makeText(ctx, "Repositorio guardado", Toast.LENGTH_SHORT).show()
            }
        }

        updateMsg?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, fontSize = 16.sp, color = Green, modifier = Modifier.padding(start = 8.dp))
        }
    }
}

@Composable
private fun CategoryRow(title: String, count: Int, modifier: Modifier, onClick: () -> Unit) {
    FocusRow(modifier, onClick) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(12.dp))
        Text("$count", fontSize = 18.sp, color = Gray)
    }
}

@Composable
private fun ChannelsPanel(
    modifier: Modifier,
    title: String,
    list: List<Channel>,
    current: Channel,
    onPick: (List<Channel>, Int) -> Unit
) {
    val focus = remember { FocusRequester() }
    val start = list.indexOfFirst { it.url == current.url }.coerceAtLeast(0)
    val state = rememberLazyListState(initialFirstVisibleItemIndex = start)
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    SidePanel(modifier, 560.dp) {
        Text("‹  $title", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
        Spacer(Modifier.height(8.dp))
        LazyColumn(state = state) {
            itemsIndexed(list) { i, ch ->
                ChannelRow(ch, if (i == start) Modifier.focusRequester(focus) else Modifier) {
                    onPick(list, i)
                }
            }
        }
    }
}

@Composable
private fun SearchPanel(
    modifier: Modifier,
    index: List<Pair<Channel, String>>,
    hidden: Set<String>,
    onPick: (List<Channel>, Int) -> Unit
) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    val results = remember(q, hidden) {
        val tokens = normalize(q).split(" ").filter { it.isNotBlank() }
        if (tokens.isEmpty()) emptyList()
        else index
            .filter { (c, n) -> c.group !in hidden && tokens.all { n.contains(it) } }
            .map { it.first }
            .take(300)
    }

    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !text.isNullOrBlank()) q = text
    }
    fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Di el nombre del canal")
        }
        try {
            voice.launch(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "Este dispositivo no tiene reconocimiento de voz", Toast.LENGTH_LONG).show()
        }
    }

    SidePanel(modifier, 760.dp) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp)) {
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                singleLine = true,
                label = { Text("Buscar canal") },
                modifier = Modifier.weight(1f).focusRequester(focus)
            )
            Spacer(Modifier.width(12.dp))
            FocusChip("Voz") { startVoice() }
        }
        Spacer(Modifier.height(12.dp))
        when {
            q.isBlank() -> Text("Escribe o dicta el nombre del canal", color = Gray, modifier = Modifier.padding(start = 8.dp))
            results.isEmpty() -> Text("Sin resultados", color = Gray, modifier = Modifier.padding(start = 8.dp))
            else -> LazyColumn {
                itemsIndexed(results) { i, ch ->
                    ChannelRow(ch) { onPick(results, i) }
                }
            }
        }
    }
}

@Composable
private fun ManagePanel(
    modifier: Modifier,
    order: List<String>,
    hidden: Set<String>,
    counts: Map<String, Int>,
    onMove: (Int, Int) -> Unit,
    onToggle: (String) -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    SidePanel(modifier, 760.dp) {
        Text("Editar categorías", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
        Text(
            "▲ ▼ para ordenar, Ocultar para esconderla",
            fontSize = 16.sp, color = Gray, modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
        )
        LazyColumn {
            itemsIndexed(order, key = { _, g -> g }) { i, g ->
                val isHidden = g in hidden
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            g, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                            color = if (isHidden) Color(0xFF777777) else Color.White
                        )
                        Text("${counts[g] ?: 0} canales", fontSize = 16.sp, color = Gray)
                    }
                    FocusChip("▲", if (i == 0) Modifier.focusRequester(focus) else Modifier) { onMove(i, -1) }
                    Spacer(Modifier.width(8.dp))
                    FocusChip("▼") { onMove(i, 1) }
                    Spacer(Modifier.width(8.dp))
                    FocusChip(if (isHidden) "Mostrar" else "Ocultar") { onToggle(g) }
                }
            }
        }
    }
}

// ---------------- Componentes ----------------

@Composable
private fun FocusChip(
    text: String,
    modifier: Modifier = Modifier,
    activeColor: Color = Blue,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(if (focused) activeColor else Color(0x33FFFFFF))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) { Text(text, fontSize = 18.sp, color = Color.White) }
}

@Composable
private fun FocusRow(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    content: @Composable RowScope.(Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(40.dp))
            .background(if (focused) Blue else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) { this.content(focused) }
}

@Composable
private fun ChannelRow(ch: Channel, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FocusRow(modifier, onClick) { focused ->
        Logo(ch.logo, if (focused) 68.dp else 56.dp)
        Spacer(Modifier.width(20.dp))
        Column {
            Text(ch.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("Sin información", fontSize = 18.sp, color = Gray, maxLines = 1)
        }
    }
}

@Composable
fun Clock(modifier: Modifier = Modifier) {
    val fmt = remember { SimpleDateFormat("hh:mm a - EEE, d MMM yyyy", Locale("es", "MX")) }
    var now by remember { mutableStateOf(fmt.format(Date())) }
    LaunchedEffect(Unit) {
        while (true) { now = fmt.format(Date()); delay(15000) }
    }
    Pill(now, modifier, 22.sp)
}

@Composable
fun Pill(text: String, modifier: Modifier = Modifier, size: TextUnit = 18.sp) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0x66000000))
            .padding(horizontal = 18.dp, vertical = 8.dp)
    ) { Text(text, fontSize = size, color = Color.White) }
}

@Composable
fun Logo(url: String?, size: Dp) {
    AsyncImage(
        model = url,
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(Color.White)
    )
}

@Composable
fun PlayerOverlay(ch: Channel, res: String, modifier: Modifier = Modifier) {
    val header = if (ch.number != null) "${ch.group} | ${ch.number} • ${ch.name}" else "${ch.group} • ${ch.name}"
    Box(
        modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF2000000))))
            .padding(horizontal = 32.dp, vertical = 28.dp)
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Logo(ch.logo, 110.dp)
            Spacer(Modifier.width(24.dp))
            Column(Modifier.weight(1f)) {
                Text(header, fontSize = 22.sp, color = Gray, fontWeight = FontWeight.Bold)
                Text("Sin información", fontSize = 36.sp, fontWeight = FontWeight.Medium)
            }
            if (res.isNotEmpty()) Pill(res)
        }
    }
}
