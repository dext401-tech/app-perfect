plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val envVersionCode = System.getenv("VERSION_CODE")?.toIntOrNull()?.plus(100) ?: 3
val envVersionName = System.getenv("VERSION_NAME") ?: "1.0"
val envGithubRepo = System.getenv("GITHUB_REPO") ?: ""

android {
    namespace = "com.mc.iptv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mc.iptv"
        minSdk = 23
        targetSdk = 34
        versionCode = envVersionCode
        versionName = envVersionName
        buildConfigField("String", "GITHUB_REPO", "\"$envGithubRepo\"")
    }

    signingConfigs {
        create("release") {
            storeFile = file("release.jks")
            storePassword = System.getenv("KS_PASS") ?: "mctv1234"
            keyAlias = System.getenv("KEY_ALIAS") ?: "mctv"
            keyPassword = System.getenv("KEY_PASS") ?: "mctv1234"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("release")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    applicationVariants.all {
        outputs.all {
            val outputImpl = this as com.android.build.gradle.internal.api.BaseVariantOutputImpl
            outputImpl.outputFileName = "MCTV.apk"
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("io.coil-kt:coil-compose:2.6.0")
}
