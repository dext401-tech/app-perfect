plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mc.iptv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mc.iptv"
        minSdk = 23
        targetSdk = 34
        versionCode = 17
        versionName = "0.14"
    }
    signingConfigs {
        create("mctv") {
            storeFile = file("mctv.jks")
            storePassword = "mctvstore"
            keyAlias = "mctv"
            keyPassword = "mctvstore"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("mctv") }
        getByName("release") { signingConfig = signingConfigs.getByName("mctv") }
    }

    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
