package com.mc.iptv

data class Channel(
    val name: String,
    val url: String,
    val logo: String?,
    val group: String,
    val number: String?
)

object M3uParser {
    private val attr = Regex("([\\w-]+)=\"([^\"]*)\"")

    fun parse(text: String): List<Channel> {
        val out = mutableListOf<Channel>()
        var name = ""
        var logo: String? = null
        var group = "Sin grupo"
        var num: String? = null
        var pending = false

        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> {
                    val a = attr.findAll(line).associate { it.groupValues[1] to it.groupValues[2] }
                    name = line.substringAfterLast(",").trim()
                        .ifEmpty { a["tvg-name"] ?: "Canal" }
                    logo = a["tvg-logo"]?.takeIf { it.isNotBlank() }
                    group = a["group-title"]?.takeIf { it.isNotBlank() } ?: "Sin grupo"
                    num = a["tvg-chno"]?.takeIf { it.isNotBlank() }
                    pending = true
                }
                line.isNotEmpty() && !line.startsWith("#") && pending -> {
                    out += Channel(name, line, logo, group, num)
                    pending = false
                }
            }
        }
        return out
    }
}
