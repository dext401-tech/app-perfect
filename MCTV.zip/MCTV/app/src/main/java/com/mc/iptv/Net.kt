package com.mc.iptv

import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Cliente de red compartido por todos los reproductores:
 *  - reutiliza conexiones (no vuelve a negociar con el servidor en cada canal)
 *  - recuerda a dónde redirige cada canal (10 min) para saltarse ese viaje extra
 */
object Net {
    private class Hit(val url: String, val at: Long)

    private val redirects = ConcurrentHashMap<String, Hit>()
    private const val TTL_MS = 10 * 60 * 1000L

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .connectionPool(ConnectionPool(8, 5, TimeUnit.MINUTES))
            .followRedirects(true)
            .followSslRedirects(true)
            .addInterceptor { chain ->
                val orig = chain.request()
                val key = orig.url.toString()
                val hit = redirects[key]
                if (hit != null) {
                    if (System.currentTimeMillis() - hit.at < TTL_MS) {
                        val r = try {
                            chain.proceed(orig.newBuilder().url(hit.url).build())
                        } catch (e: IOException) {
                            null
                        }
                        if (r != null && r.isSuccessful) return@addInterceptor r
                        r?.close()
                    }
                    redirects.remove(key) // el destino guardado ya no sirve: vuelve al camino normal
                }
                val resp = chain.proceed(orig)
                val finalUrl = resp.request.url.toString()
                if (resp.isSuccessful && finalUrl != key && resp.priorResponse != null) {
                    redirects[key] = Hit(finalUrl, System.currentTimeMillis())
                }
                resp
            }
            .build()
    }
}
