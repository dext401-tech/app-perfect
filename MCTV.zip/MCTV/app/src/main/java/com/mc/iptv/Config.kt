package com.mc.iptv

object Config {
    // Repositorio de GitHub donde se publican las versiones (Releases)
    const val UPDATE_REPO = "dext401-tech/app-perfect"
}
