package com.mc.iptv

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Blue = Color(0xFF3B82F6)
private val Gray = Color(0xFFB0B0B0)
private val accents = Regex("\\p{Mn}+")

private enum class Mode { NONE, CATEGORIES, CHANNELS, SEARCH, MANAGE, SETTINGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = Color.Black, contentColor = Color.White) {
                    App()
                }
            }
        }
    }
}

private fun download(url: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 15000
    c.readTimeout = 30000
    c.setRequestProperty("User-Agent", "MCTV/0.3")
    return c.inputStream.bufferedReader().use { it.readText() }
}

private fun normalize(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD).replace(accents, "").lowercase(Locale.ROOT)

private fun mergeOrder(saved: String, all: List<String>): List<String> {
    val set = all.toSet()
    val s = saved.split("\n").filter { it in set }
    val seen = s.toSet()
    return s + all.filter { it !in seen }
}

private fun moveItem(list: List<String>, i: Int, d: Int): List<String> {
    val j = i + d
    if (j !in list.indices) return list
    val m = list.toMutableList()
    val t = m[i]; m[i] = m[j]; m[j] = t
    return m
}

// ---------------- App ----------------

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("mctv", 0) }
    var url by remember { mutableStateOf(prefs.getString("m3u", "") ?: "") }
    var reload by remember { mutableIntStateOf(0) }
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var update by remember { mutableStateOf<UpdateInfo?>(null) }
    var updateMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(url, reload) {
        if (url.isBlank()) return@LaunchedEffect
        loading = true
        error = null
        try {
            channels = withContext(Dispatchers.IO) { M3uParser.parse(download(url)) }
            if (channels.isEmpty()) error = "La lista no tiene canales"
        } catch (e: Exception) {
            error = e.message ?: "Error al cargar la lista"
        }
        loading = false
    }

    // Buscar actualización al abrir (si está activado en Ajustes)
    LaunchedEffect(Unit) {
        if (prefs.getBoolean("auto_update", true)) {
            try { update = Updater.check(ctx) } catch (_: Exception) {}
        }
    }

    fun checkNow() {
        updateMsg = "Buscando..."
        scope.launch {
            try {
                val u = Updater.check(ctx)
                if (u != null) { update = u; updateMsg = null } else updateMsg = "Ya tienes la última"
            } catch (e: Exception) {
                updateMsg = "Sin conexión"
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (channels.isEmpty()) {
            SetupScreen(url, loading, error) {
                prefs.edit().putString("m3u", it).apply()
                url = it
                reload++
            }
        } else {
            PlayerScreen(
                channels = channels,
                prefs = prefs,
                dialogOpen = update != null,
                updateMsg = updateMsg,
                onCheckUpdate = { checkNow() },
                onChangeUrl = {
                    prefs.edit().putString("m3u", it).apply()
                    channels = emptyList()
                    url = it
                    reload++
                },
                onReload = {
                    channels = emptyList()
                    reload++
                }
            )
        }

        update?.let { UpdateDialog(it) { update = null } }
    }
}

@Composable
private fun UpdateDialog(info: UpdateInfo, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var progress by remember { mutableStateOf<Int?>(null) }
    var msg by remember { mutableStateOf<String?>(null) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    BackHandler { onDismiss() }

    fun start() {
        if (!Updater.canInstall(ctx)) {
            msg = "Activa «Instalar apps desconocidas» para MC TV y vuelve a tocar Actualizar"
            try {
                Updater.openInstallPermission(ctx)
            } catch (e: Exception) {
                Toast.makeText(ctx, "Abre Ajustes de la TV y permite instalar apps desconocidas", Toast.LENGTH_LONG).show()
            }
            return
        }
        progress = 0
        scope.launch {
            try {
                val f = Updater.download(ctx, info.apkUrl) { progress = it }
                progress = null
                Updater.install(ctx, f)
            } catch (e: Exception) {
                progress = null
                msg = "No se pudo descargar: ${e.message}"
            }
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .width(640.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF1A1D24))
                .padding(32.dp)
        ) {
            Text("Nueva versión ${info.version}", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Tienes la ${Updater.currentVersion(ctx)}", fontSize = 20.sp, color = Gray)
            msg?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, fontSize = 18.sp, color = Color(0xFFFFC857))
            }
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                FocusChip(
                    if (progress != null) "Descargando ${progress}%" else "Actualizar",
                    Modifier.focusRequester(focus)
                ) { if (progress == null) start() }
                FocusChip("Después") { onDismiss() }
            }
        }
    }
}

@Composable
fun SetupScreen(initial: String, loading: Boolean, error: String?, onLoad: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    Column(
        Modifier.fillMaxSize().padding(80.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("MC TV", fontSize = 40.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("URL de tu lista M3U") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(0.7f)
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = { onLoad(text.trim()) }, enabled = !loading && text.isNotBlank()) {
            Text(if (loading) "Cargando..." else "Cargar lista")
        }
        error?.let {
            Spacer(Modifier.height(16.dp))
            Text(it, color = Color(0xFFFF6B6B))
        }
    }
}

// ---------------- Reproductor ----------------

@Composable
private fun PlayerScreen(
    channels: List<Channel>,
    prefs: SharedPreferences,
    dialogOpen: Boolean,
    updateMsg: String?,
    onCheckUpdate: () -> Unit,
    onChangeUrl: (String) -> Unit,
    onReload: () -> Unit
) {
    val ctx = LocalContext.current

    // ---- Ajustes (se guardan en prefs) ----
    var bufferLevel by remember { mutableIntStateOf(prefs.getInt("buffer", 1)) }
    var overlaySecs by remember { mutableIntStateOf(prefs.getInt("overlay_s", 5)) }
    var autoUpdate by remember { mutableStateOf(prefs.getBoolean("auto_update", true)) }

    // El reproductor se vuelve a crear si cambias el tamaño del buffer
    val player = remember(bufferLevel) {
        val (minMs, maxMs) = when (bufferLevel) {
            0 -> 10000 to 20000
            2 -> 30000 to 60000
            else -> 20000 to 40000
        }
        val http = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)
            .setAllowCrossProtocolRedirects(true)
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(minMs, maxMs, 2500, 5000)
            .build()
        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .setLoadControl(load)
            .build()
    }

    // ---- Categorías: orden y ocultas (se guardan en prefs) ----
    val allGroups = remember(channels) { channels.map { it.group }.distinct() }
    val counts = remember(channels) { channels.groupingBy { it.group }.eachCount() }
    val searchIndex = remember(channels) { channels.map { it to normalize(it.name) } }
    var order by remember(allGroups) {
        mutableStateOf(mergeOrder(prefs.getString("cat_order", "") ?: "", allGroups))
    }
    var hidden by remember(allGroups) {
        mutableStateOf((prefs.getStringSet("cat_hidden", emptySet()) ?: emptySet()).toSet())
    }
    fun save() {
        prefs.edit()
            .putString("cat_order", order.joinToString("\n"))
            .putStringSet("cat_hidden", hidden.toSet())
            .apply()
    }
    val visible = remember(channels, hidden) {
        channels.filter { it.group !in hidden }.ifEmpty { channels }
    }

    // ---- Reproducción ----
    var playlist by remember { mutableStateOf(visible) }
    var index by remember { mutableIntStateOf(0) }
    val current = playlist.getOrNull(index) ?: channels.first()

    var mode by remember { mutableStateOf(Mode.NONE) }
    var openGroup by remember { mutableStateOf<String?>(null) } // null = Todos
    var overlay by remember { mutableStateOf(true) }
    var size by remember { mutableStateOf(VideoSize.UNKNOWN) }
    var failures by remember { mutableIntStateOf(0) }
    var buffering by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    val rootFocus = remember { FocusRequester() }

    fun step(d: Int) {
        if (playlist.isEmpty()) return
        index = (index + d + playlist.size) % playlist.size
    }
    fun pick(list: List<Channel>, i: Int) {
        playlist = list
        index = i
        mode = Mode.NONE
    }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) { size = videoSize }
            override fun onPlayerError(error: PlaybackException) { failures += 1 }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) { failures = 0; status = null }
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    LaunchedEffect(current.url, player) {
        size = VideoSize.UNKNOWN
        failures = 0
        status = null
        player.setMediaItem(MediaItem.fromUri(current.url))
        player.prepare()
        player.playWhenReady = true
        overlay = true
    }
    LaunchedEffect(overlay, current.url) {
        if (overlay) { delay(overlaySecs * 1000L); overlay = false }
    }
    LaunchedEffect(mode, dialogOpen) {
        if (mode == Mode.NONE && !dialogOpen) runCatching { rootFocus.requestFocus() }
    }
    // Reintenta solo si el stream falla (pausas de 1, 2, 4... hasta 8 s)
    LaunchedEffect(failures, player) {
        if (failures == 0) return@LaunchedEffect
        if (failures > 6) { status = "Sin señal"; return@LaunchedEffect }
        status = "Reconectando... ($failures)"
        delay(minOf(1000L shl (failures - 1), 8000L))
        player.setMediaItem(MediaItem.fromUri(current.url))
        player.prepare()
        player.playWhenReady = true
    }
    // Si se queda cargando más de 15 s, cuenta como falla
    LaunchedEffect(buffering, failures, current.url) {
        if (buffering && failures <= 6) { delay(15000); failures += 1 }
    }

    BackHandler(enabled = mode != Mode.NONE || overlay) {
        when (mode) {
            Mode.NONE -> overlay = false
            Mode.CATEGORIES -> mode = Mode.NONE
            else -> mode = Mode.CATEGORIES
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown || mode != Mode.NONE) return@onPreviewKeyEvent false
                when (e.key) {
                    Key.DirectionLeft -> { mode = Mode.CATEGORIES; true }
                    Key.DirectionCenter, Key.Enter -> { overlay = !overlay; true }
                    Key.DirectionUp, Key.ChannelUp -> { step(1); true }
                    Key.DirectionDown, Key.ChannelDown -> { step(-1); true }
                    else -> false
                }
            }
            .focusRequester(rootFocus)
            .focusable()
    ) {
        AndroidView(
            factory = { PlayerView(it).apply { useController = false } },
            update = { it.player = player },
            modifier = Modifier.fillMaxSize()
        )

        if (overlay && mode == Mode.NONE) {
            val res = if (size.height > 0) "${size.width}x${size.height}" else ""
            Clock(Modifier.align(Alignment.TopEnd).padding(24.dp))
            PlayerOverlay(current, res, Modifier.align(Alignment.BottomCenter))
        }

        status?.let { Pill(it, Modifier.align(Alignment.Center), 26.sp) }

        val side = Modifier.align(Alignment.CenterStart)
        when (mode) {
            Mode.NONE -> {}
            Mode.CATEGORIES -> CategoriesPanel(
                modifier = side,
                groups = order.filter { it !in hidden }.map { it to (counts[it] ?: 0) },
                total = visible.size,
                selected = openGroup,
                onAll = { openGroup = null; mode = Mode.CHANNELS },
                onGroup = { openGroup = it; mode = Mode.CHANNELS },
                onSearch = { mode = Mode.SEARCH },
                onManage = { mode = Mode.MANAGE },
                onSettings = { mode = Mode.SETTINGS }
            )
            Mode.CHANNELS -> {
                val g = openGroup
                val list = remember(g, channels, visible) {
                    if (g == null) visible else channels.filter { it.group == g }
                }
                ChannelsPanel(side, g ?: "Todos", list, current) { l, i -> pick(l, i) }
            }
            Mode.SEARCH -> SearchPanel(side, searchIndex, hidden) { l, i -> pick(l, i) }
            Mode.MANAGE -> ManagePanel(
                modifier = side,
                order = order,
                hidden = hidden,
                counts = counts,
                onMove = { i, d -> order = moveItem(order, i, d); save() },
                onToggle = { g ->
                    hidden = if (g in hidden) hidden - g else hidden + g
                    save()
                }
            )
            Mode.SETTINGS -> SettingsPanel(
                modifier = side,
                version = Updater.currentVersion(ctx),
                url = prefs.getString("m3u", "") ?: "",
                bufferLevel = bufferLevel,
                overlaySecs = overlaySecs,
                autoUpdate = autoUpdate,
                updateMsg = updateMsg,
                onBuffer = {
                    bufferLevel = (bufferLevel + 1) % 3
                    prefs.edit().putInt("buffer", bufferLevel).apply()
                },
                onOverlay = {
                    val opts = listOf(3, 5, 8, 12)
                    overlaySecs = opts[(opts.indexOf(overlaySecs).coerceAtLeast(0) + 1) % opts.size]
                    prefs.edit().putInt("overlay_s", overlaySecs).apply()
                },
                onAutoUpdate = {
                    autoUpdate = !autoUpdate
                    prefs.edit().putBoolean("auto_update", autoUpdate).apply()
                },
                onCheckUpdate = onCheckUpdate,
                onReload = onReload,
                onSaveUrl = { if (it.isNotBlank()) onChangeUrl(it) }
            )
        }
    }
}

// ---------------- Paneles ----------------

@Composable
private fun SidePanel(modifier: Modifier, width: Dp, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxHeight()
            .width(width)
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xF5000000), Color(0xD9000000), Color.Transparent)
                )
            )
            .padding(start = 16.dp, end = 48.dp, top = 24.dp, bottom = 16.dp),
        content = content
    )
}

@Composable
private fun CategoriesPanel(
    modifier: Modifier,
    groups: List<Pair<String, Int>>,
    total: Int,
    selected: String?,
    onAll: () -> Unit,
    onGroup: (String) -> Unit,
    onSearch: () -> Unit,
    onManage: () -> Unit,
    onSettings: () -> Unit
) {
    val focus = remember { FocusRequester() }
    val selIdx = if (selected == null) 0 else groups.indexOfFirst { it.first == selected } + 1
    val state = rememberLazyListState(initialFirstVisibleItemIndex = selIdx.coerceAtLeast(0))
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    SidePanel(modifier, 700.dp) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(start = 8.dp)) {
            FocusChip("Buscar", onClick = onSearch)
            FocusChip("Editar categorías", onClick = onManage)
            FocusChip("Ajustes", onClick = onSettings)
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(state = state) {
            item {
                CategoryRow(
                    "Todos", total,
                    if (selected == null) Modifier.focusRequester(focus) else Modifier,
                    onAll
                )
            }
            itemsIndexed(groups, key = { _, g -> g.first }) { _, g ->
                CategoryRow(
                    g.first, g.second,
                    if (g.first == selected) Modifier.focusRequester(focus) else Modifier
                ) { onGroup(g.first) }
            }
        }
    }
}

@Composable
private fun CategoryRow(title: String, count: Int, modifier: Modifier, onClick: () -> Unit) {
    FocusRow(modifier, onClick) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(12.dp))
        Text("$count", fontSize = 18.sp, color = Gray)
    }
}

@Composable
private fun ChannelsPanel(
    modifier: Modifier,
    title: String,
    list: List<Channel>,
    current: Channel,
    onPick: (List<Channel>, Int) -> Unit
) {
    val focus = remember { FocusRequester() }
    val start = list.indexOfFirst { it.url == current.url }.coerceAtLeast(0)
    val state = rememberLazyListState(initialFirstVisibleItemIndex = start)
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    SidePanel(modifier, 560.dp) {
        Text("‹  $title", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
        Spacer(Modifier.height(8.dp))
        LazyColumn(state = state) {
            itemsIndexed(list) { i, ch ->
                ChannelRow(ch, if (i == start) Modifier.focusRequester(focus) else Modifier) {
                    onPick(list, i)
                }
            }
        }
    }
}

@Composable
private fun SearchPanel(
    modifier: Modifier,
    index: List<Pair<Channel, String>>,
    hidden: Set<String>,
    onPick: (List<Channel>, Int) -> Unit
) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    val results = remember(q, hidden) {
        val tokens = normalize(q).split(" ").filter { it.isNotBlank() }
        if (tokens.isEmpty()) emptyList()
        else index
            .filter { (c, n) -> c.group !in hidden && tokens.all { n.contains(it) } }
            .map { it.first }
            .take(300)
    }

    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !text.isNullOrBlank()) q = text
    }
    fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Di el nombre del canal")
        }
        try {
            voice.launch(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "Este dispositivo no tiene reconocimiento de voz", Toast.LENGTH_LONG).show()
        }
    }

    SidePanel(modifier, 760.dp) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp)) {
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                singleLine = true,
                label = { Text("Buscar canal") },
                modifier = Modifier.weight(1f).focusRequester(focus)
            )
            Spacer(Modifier.width(12.dp))
            FocusChip("Voz") { startVoice() }
        }
        Spacer(Modifier.height(12.dp))
        when {
            q.isBlank() -> Text("Escribe o dicta el nombre del canal", color = Gray, modifier = Modifier.padding(start = 8.dp))
            results.isEmpty() -> Text("Sin resultados", color = Gray, modifier = Modifier.padding(start = 8.dp))
            else -> LazyColumn {
                itemsIndexed(results) { i, ch ->
                    ChannelRow(ch) { onPick(results, i) }
                }
            }
        }
    }
}

@Composable
private fun ManagePanel(
    modifier: Modifier,
    order: List<String>,
    hidden: Set<String>,
    counts: Map<String, Int>,
    onMove: (Int, Int) -> Unit,
    onToggle: (String) -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    SidePanel(modifier, 760.dp) {
        Text("Editar categorías", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
        Text(
            "▲ ▼ para ordenar, Ocultar para esconderla",
            fontSize = 16.sp, color = Gray, modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
        )
        LazyColumn {
            itemsIndexed(order, key = { _, g -> g }) { i, g ->
                val isHidden = g in hidden
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            g, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                            color = if (isHidden) Color(0xFF777777) else Color.White
                        )
                        Text("${counts[g] ?: 0} canales", fontSize = 16.sp, color = Gray)
                    }
                    FocusChip("▲", if (i == 0) Modifier.focusRequester(focus) else Modifier) { onMove(i, -1) }
                    Spacer(Modifier.width(8.dp))
                    FocusChip("▼") { onMove(i, 1) }
                    Spacer(Modifier.width(8.dp))
                    FocusChip(if (isHidden) "Mostrar" else "Ocultar") { onToggle(g) }
                }
            }
        }
    }
}

@Composable
private fun SettingsPanel(
    modifier: Modifier,
    version: String,
    url: String,
    bufferLevel: Int,
    overlaySecs: Int,
    autoUpdate: Boolean,
    updateMsg: String?,
    onBuffer: () -> Unit,
    onOverlay: () -> Unit,
    onAutoUpdate: () -> Unit,
    onCheckUpdate: () -> Unit,
    onReload: () -> Unit,
    onSaveUrl: (String) -> Unit
) {
    val focus = remember { FocusRequester() }
    var text by remember { mutableStateOf(url) }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    val labels = listOf("Bajo", "Normal", "Alto")

    SidePanel(modifier, 760.dp) {
        Text(
            "Ajustes", fontSize = 28.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
        )
        SettingRow("Buffer del video", labels[bufferLevel.coerceIn(0, 2)], Modifier.focusRequester(focus), onBuffer)
        SettingRow("Duración de la barra de info", "$overlaySecs s", onClick = onOverlay)
        SettingRow("Buscar actualizaciones al abrir", if (autoUpdate) "Sí" else "No", onClick = onAutoUpdate)
        SettingRow("Buscar actualización ahora", updateMsg ?: "Versión $version", onClick = onCheckUpdate)
        SettingRow("Recargar lista de canales", "", onClick = onReload)
        Spacer(Modifier.height(16.dp))
        Text("Lista M3U", fontSize = 18.sp, color = Gray, modifier = Modifier.padding(start = 8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp)) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(12.dp))
            FocusChip("Guardar") { onSaveUrl(text.trim()) }
        }
    }
}

@Composable
private fun SettingRow(label: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FocusRow(modifier, onClick) {
        Text(label, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (value.isNotEmpty()) Text(value, fontSize = 20.sp, color = Gray)
    }
}

// ---------------- Componentes ----------------

@Composable
private fun FocusChip(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(if (focused) Blue else Color(0x33FFFFFF))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) { Text(text, fontSize = 18.sp, color = Color.White) }
}

@Composable
private fun FocusRow(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    content: @Composable RowScope.(Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(40.dp))
            .background(if (focused) Blue else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) { this.content(focused) }
}

@Composable
private fun ChannelRow(ch: Channel, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FocusRow(modifier, onClick) { focused ->
        Logo(ch.logo, if (focused) 68.dp else 56.dp)
        Spacer(Modifier.width(20.dp))
        Column {
            Text(ch.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("Sin información", fontSize = 18.sp, color = Gray, maxLines = 1)
        }
    }
}

@Composable
fun Clock(modifier: Modifier = Modifier) {
    val fmt = remember { SimpleDateFormat("hh:mm a - EEE, d MMM yyyy", Locale("es", "MX")) }
    var now by remember { mutableStateOf(fmt.format(Date())) }
    LaunchedEffect(Unit) {
        while (true) { now = fmt.format(Date()); delay(15000) }
    }
    Pill(now, modifier, 22.sp)
}

@Composable
fun Pill(text: String, modifier: Modifier = Modifier, size: TextUnit = 18.sp) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0x66000000))
            .padding(horizontal = 18.dp, vertical = 8.dp)
    ) { Text(text, fontSize = size, color = Color.White) }
}

@Composable
fun Logo(url: String?, size: Dp) {
    AsyncImage(
        model = url,
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(Color.White)
    )
}

@Composable
fun PlayerOverlay(ch: Channel, res: String, modifier: Modifier = Modifier) {
    val header = if (ch.number != null) "${ch.group} | ${ch.number} • ${ch.name}" else "${ch.group} • ${ch.name}"
    Box(
        modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF2000000))))
            .padding(horizontal = 32.dp, vertical = 28.dp)
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Logo(ch.logo, 110.dp)
            Spacer(Modifier.width(24.dp))
            Column(Modifier.weight(1f)) {
                Text(header, fontSize = 22.sp, color = Gray, fontWeight = FontWeight.Bold)
                Text("Sin información", fontSize = 36.sp, fontWeight = FontWeight.Medium)
            }
            if (res.isNotEmpty()) Pill(res)
        }
    }
}
