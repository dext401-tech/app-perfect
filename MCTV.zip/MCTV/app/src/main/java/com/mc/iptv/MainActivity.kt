package com.mc.iptv

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Blue = Color(0xFF3B82F6)
private val Violet = Color(0xFF8B5CF6)
private val Gold = Color(0xFFFFC857)
private val Gray = Color(0xFFB0B0B0)
private val Red = Color(0xFFFF4D4D)
private val AccentBrush: Brush = Brush.horizontalGradient(listOf(Blue, Violet))
private val accents = Regex("\\p{Mn}+")

private enum class Mode { NONE, QUICK, CATEGORIES, CHANNELS, FAVORITES, SEARCH, MANAGE, SETTINGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Blue, secondary = Violet)) {
                Surface(Modifier.fillMaxSize(), color = Color.Black, contentColor = Color.White) {
                    App()
                }
            }
        }
    }
}

private fun download(url: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 15000
    c.readTimeout = 30000
    c.setRequestProperty("User-Agent", "MCTV/0.4")
    return c.inputStream.bufferedReader().use { it.readText() }
}

private fun normalize(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD).replace(accents, "").lowercase(Locale.ROOT)

private fun mergeOrder(saved: String, all: List<String>): List<String> {
    val set = all.toSet()
    val s = saved.split("\n").filter { it in set }
    val seen = s.toSet()
    return s + all.filter { it !in seen }
}

private fun moveItem(list: List<String>, i: Int, d: Int): List<String> {
    val j = i + d
    if (j !in list.indices) return list
    val m = list.toMutableList()
    val t = m[i]; m[i] = m[j]; m[j] = t
    return m
}

private fun moveTo(list: List<String>, g: String, pos: Int): List<String> {
    val m = list.toMutableList()
    if (!m.remove(g)) return list
    m.add(pos.coerceIn(0, m.size), g)
    return m
}

// ---------------- App ----------------

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("mctv", 0) }
    var url by remember { mutableStateOf(prefs.getString("m3u", "") ?: "") }
    var reload by remember { mutableIntStateOf(0) }
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var update by remember { mutableStateOf<UpdateInfo?>(null) }
    var updateMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(url, reload) {
        if (url.isBlank()) return@LaunchedEffect
        loading = true
        error = null
        try {
            channels = withContext(Dispatchers.IO) { M3uParser.parse(download(url)) }
            if (channels.isEmpty()) error = "La lista no tiene canales"
        } catch (e: Exception) {
            error = e.message ?: "Error al cargar la lista"
        }
        loading = false
    }

    // Buscar actualización al abrir (si está activado en Ajustes)
    LaunchedEffect(Unit) {
        if (prefs.getBoolean("auto_update", true)) {
            try { update = Updater.check(ctx) } catch (_: Exception) {}
        }
    }

    fun checkNow() {
        updateMsg = "Buscando..."
        scope.launch {
            try {
                val u = Updater.check(ctx)
                if (u != null) { update = u; updateMsg = null } else updateMsg = "Ya tienes la última"
            } catch (e: Exception) {
                updateMsg = "Sin conexión"
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (channels.isEmpty()) {
            SetupScreen(url, loading, error) {
                prefs.edit().putString("m3u", it).apply()
                url = it
                reload++
            }
        } else {
            PlayerScreen(
                channels = channels,
                prefs = prefs,
                dialogOpen = update != null,
                updateMsg = updateMsg,
                onCheckUpdate = { checkNow() },
                onChangeUrl = {
                    prefs.edit().putString("m3u", it).apply()
                    channels = emptyList()
                    url = it
                    reload++
                },
                onReload = {
                    channels = emptyList()
                    reload++
                }
            )
        }

        update?.let { UpdateDialog(it) { update = null } }
    }
}

@Composable
fun AppLogo(size: Dp) {
    Image(
        painter = painterResource(R.drawable.logo),
        contentDescription = null,
        modifier = Modifier.size(size).clip(RoundedCornerShape(size / 5))
    )
}

@Composable
private fun UpdateDialog(info: UpdateInfo, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var progress by remember { mutableStateOf<Int?>(null) }
    var msg by remember { mutableStateOf<String?>(null) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    BackHandler { onDismiss() }

    fun start() {
        if (!Updater.canInstall(ctx)) {
            msg = "Activa «Instalar apps desconocidas» para MC TV y vuelve a tocar Actualizar"
            try {
                Updater.openInstallPermission(ctx)
            } catch (e: Exception) {
                Toast.makeText(ctx, "Abre Ajustes de la TV y permite instalar apps desconocidas", Toast.LENGTH_LONG).show()
            }
            return
        }
        progress = 0
        scope.launch {
            try {
                val f = Updater.download(ctx, info.apkUrl) { progress = it }
                progress = null
                Updater.install(ctx, f)
            } catch (e: Exception) {
                progress = null
                msg = "No se pudo descargar: ${e.message}"
            }
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .width(640.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF131827))
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(24.dp))
                .padding(32.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppLogo(64.dp)
                Spacer(Modifier.width(18.dp))
                Column {
                    Text("Nueva versión ${info.version}", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("Tienes la ${Updater.currentVersion(ctx)}", fontSize = 20.sp, color = Gray)
                }
            }
            msg?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, fontSize = 18.sp, color = Gold)
            }
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                FocusChip(
                    if (progress != null) "Descargando ${progress}%" else "Actualizar",
                    Modifier.focusRequester(focus)
                ) { if (progress == null) start() }
                FocusChip("Después") { onDismiss() }
            }
        }
    }
}

@Composable
fun SetupScreen(initial: String, loading: Boolean, error: String?, onLoad: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B0F1A), Color(0xFF1B1440))))
    ) {
        Column(
            Modifier.fillMaxSize().padding(80.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AppLogo(140.dp)
            Spacer(Modifier.height(20.dp))
            Text("MC TV", fontSize = 44.sp, fontWeight = FontWeight.Bold)
            Text("Tu televisión en vivo", fontSize = 20.sp, color = Gray)
            Spacer(Modifier.height(32.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("URL de tu lista M3U") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(0.7f)
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { onLoad(text.trim()) }, enabled = !loading && text.isNotBlank()) {
                Text(if (loading) "Cargando..." else "Cargar lista")
            }
            error?.let {
                Spacer(Modifier.height(16.dp))
                Text(it, color = Color(0xFFFF6B6B))
            }
        }
    }
}

// ---------------- Reproductor ----------------

@Composable
private fun PlayerScreen(
    channels: List<Channel>,
    prefs: SharedPreferences,
    dialogOpen: Boolean,
    updateMsg: String?,
    onCheckUpdate: () -> Unit,
    onChangeUrl: (String) -> Unit,
    onReload: () -> Unit
) {
    val ctx = LocalContext.current

    // ---- Ajustes (se guardan en prefs) ----
    var bufferLevel by remember { mutableIntStateOf(prefs.getInt("buffer", 1)) }
    var overlaySecs by remember { mutableIntStateOf(prefs.getInt("overlay_s", 5)) }
    var autoUpdate by remember { mutableStateOf(prefs.getBoolean("auto_update", true)) }

    // El reproductor se vuelve a crear si cambias el tamaño del buffer
    val player = remember(bufferLevel) {
        val (minMs, maxMs) = when (bufferLevel) {
            0 -> 10000 to 20000
            2 -> 30000 to 60000
            else -> 20000 to 40000
        }
        val http = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)
            .setAllowCrossProtocolRedirects(true)
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(minMs, maxMs, 2500, 5000)
            .build()
        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .setLoadControl(load)
            .build()
    }

    // ---- Categorías: orden y ocultas (se guardan en prefs) ----
    val allGroups = remember(channels) { channels.map { it.group }.distinct() }
    val counts = remember(channels) { channels.groupingBy { it.group }.eachCount() }
    val searchIndex = remember(channels) { channels.map { it to normalize(it.name) } }
    var order by remember(allGroups) {
        mutableStateOf(mergeOrder(prefs.getString("cat_order", "") ?: "", allGroups))
    }
    var hidden by remember(allGroups) {
        mutableStateOf((prefs.getStringSet("cat_hidden", emptySet()) ?: emptySet()).toSet())
    }
    fun save() {
        prefs.edit()
            .putString("cat_order", order.joinToString("\n"))
            .putStringSet("cat_hidden", hidden.toSet())
            .apply()
    }
    val visible = remember(channels, hidden) {
        channels.filter { it.group !in hidden }.ifEmpty { channels }
    }

    // ---- Favoritos (se guardan por URL del canal) ----
    var favs by remember { mutableStateOf((prefs.getStringSet("favs", emptySet()) ?: emptySet()).toSet()) }
    fun toggleFav(c: Channel) {
        favs = if (c.url in favs) favs - c.url else favs + c.url
        prefs.edit().putStringSet("favs", favs.toSet()).apply()
    }
    val favList = remember(channels, favs) { channels.filter { it.url in favs } }

    // ---- Reproducción ----
    val lastUrl = remember { prefs.getString("last_url", null) }
    val initial = remember(channels) {
        val iv = visible.indexOfFirst { it.url == lastUrl }
        if (iv >= 0) visible to iv
        else {
            val ia = channels.indexOfFirst { it.url == lastUrl }
            if (ia >= 0) channels to ia else visible to 0
        }
    }
    var playlist by remember { mutableStateOf(initial.first) }
    var index by remember { mutableIntStateOf(initial.second) }
    val current = playlist.getOrNull(index) ?: channels.first()

    var mode by remember { mutableStateOf(Mode.NONE) }
    var openGroup by remember { mutableStateOf<String?>(null) } // null = Todos
    var backTo by remember { mutableStateOf(Mode.CATEGORIES) }   // a dónde regresa "Atrás"
    var numberFor by remember { mutableStateOf<String?>(null) }  // categoría a la que le pones número
    var stoppedByLeave by remember { mutableStateOf(false) }
    var resumeTick by remember { mutableIntStateOf(0) }
    var overlay by remember { mutableStateOf(true) }
    var okMode by remember { mutableStateOf(false) } // la barra se abrió con OK
    var size by remember { mutableStateOf(VideoSize.UNKNOWN) }
    var failures by remember { mutableIntStateOf(0) }
    var buffering by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    val rootFocus = remember { FocusRequester() }

    fun step(d: Int) {
        if (playlist.isEmpty()) return
        index = (index + d + playlist.size) % playlist.size
    }
    fun pick(list: List<Channel>, i: Int) {
        playlist = list
        index = i
        mode = Mode.NONE
    }
    fun openPanel(m: Mode, back: Mode) {
        backTo = back
        mode = m
    }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) { size = videoSize }
            override fun onPlayerError(error: PlaybackException) { failures += 1 }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) { failures = 0; status = null }
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    // Al presionar Home (o abrir otra pantalla) se detiene el video y el audio
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, player) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) {
                stoppedByLeave = true
                player.stop()
            } else if (event == Lifecycle.Event.ON_RESUME && stoppedByLeave) {
                stoppedByLeave = false
                resumeTick++
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    // Guarda el canal para abrir ahí la próxima vez
    LaunchedEffect(current.url) {
        prefs.edit().putString("last_url", current.url).apply()
    }

    LaunchedEffect(current.url, player, resumeTick) {
        size = VideoSize.UNKNOWN
        failures = 0
        status = null
        player.setMediaItem(MediaItem.fromUri(current.url))
        player.prepare()
        player.playWhenReady = true
        overlay = true
        okMode = false
    }
    LaunchedEffect(overlay, current.url, mode) {
        if (overlay && mode == Mode.NONE) {
            delay(overlaySecs * 1000L)
            overlay = false
            okMode = false
        }
    }
    LaunchedEffect(mode, dialogOpen) {
        if (mode == Mode.NONE && !dialogOpen) runCatching { rootFocus.requestFocus() }
    }
    // Reintenta solo si el stream falla (pausas de 1, 2, 4... hasta 8 s)
    LaunchedEffect(failures, player) {
        if (failures == 0) return@LaunchedEffect
        if (failures > 6) { status = "Sin señal"; return@LaunchedEffect }
        status = "Reconectando... ($failures)"
        delay(minOf(1000L shl (failures - 1), 8000L))
        if (stoppedByLeave) return@LaunchedEffect
        player.setMediaItem(MediaItem.fromUri(current.url))
        player.prepare()
        player.playWhenReady = true
    }
    // Si se queda cargando más de 15 s, cuenta como falla
    LaunchedEffect(buffering, failures, current.url) {
        if (buffering && failures <= 6) { delay(15000); failures += 1 }
    }

    BackHandler(enabled = mode != Mode.NONE || overlay) {
        when (mode) {
            Mode.NONE -> { overlay = false; okMode = false }
            Mode.QUICK, Mode.CATEGORIES -> mode = Mode.NONE
            else -> mode = backTo
        }
    }

    val showInfo = overlay && (mode == Mode.NONE || mode == Mode.QUICK)

    Box(
        Modifier
            .fillMaxSize()
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown || mode != Mode.NONE) return@onPreviewKeyEvent false
                when (e.key) {
                    Key.DirectionLeft -> {
                        openGroup = current.group
                        openPanel(Mode.CHANNELS, Mode.NONE)
                        true
                    }
                    Key.DirectionRight -> { openPanel(Mode.SETTINGS, Mode.NONE); true }
                    Key.DirectionCenter, Key.Enter -> {
                        if (overlay && okMode) { overlay = false; okMode = false }
                        else { overlay = true; okMode = true }
                        true
                    }
                    Key.DirectionUp, Key.ChannelUp -> { step(1); true }
                    Key.ChannelDown -> { step(-1); true }
                    Key.DirectionDown -> {
                        // OK y luego abajo: abre la barra con la lupa y la estrella
                        if (overlay && okMode) mode = Mode.QUICK else step(-1)
                        true
                    }
                    else -> false
                }
            }
            .focusRequester(rootFocus)
            .focusable()
    ) {
        AndroidView(
            factory = { PlayerView(it).apply { useController = false } },
            update = { it.player = player },
            modifier = Modifier.fillMaxSize()
        )

        AnimatedVisibility(
            visible = showInfo,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopEnd).padding(24.dp)
        ) { Clock() }

        AnimatedVisibility(
            visible = showInfo,
            enter = fadeIn() + slideInVertically { it / 2 },
            exit = fadeOut() + slideOutVertically { it / 2 },
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            val res = if (size.height > 0) "${size.width}x${size.height}" else ""
            PlayerOverlay(current, res, current.url in favs)
        }

        AnimatedVisibility(
            visible = mode == Mode.QUICK,
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it },
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 200.dp)
        ) {
            QuickBar(
                isFav = current.url in favs,
                onSearch = { openPanel(Mode.SEARCH, Mode.NONE) },
                onFavorites = { openPanel(Mode.FAVORITES, Mode.NONE) },
                onToggleFav = { toggleFav(current) }
            )
        }

        status?.let { Pill(it, Modifier.align(Alignment.Center), 26.sp) }

        val side = Modifier.align(Alignment.CenterStart)
        when (mode) {
            Mode.NONE, Mode.QUICK -> {}
            Mode.CATEGORIES -> CategoriesPanel(
                modifier = side,
                groups = order.filter { it !in hidden }.map { it to (counts[it] ?: 0) },
                total = visible.size,
                favCount = favList.size,
                selected = openGroup,
                onAll = { openGroup = null; openPanel(Mode.CHANNELS, Mode.CATEGORIES) },
                onFavorites = { openPanel(Mode.FAVORITES, Mode.CATEGORIES) },
                onGroup = { openGroup = it; openPanel(Mode.CHANNELS, Mode.CATEGORIES) },
                onSearch = { openPanel(Mode.SEARCH, Mode.CATEGORIES) },
                onManage = { openPanel(Mode.MANAGE, Mode.CATEGORIES) },
                onSettings = { openPanel(Mode.SETTINGS, Mode.CATEGORIES) }
            )
            Mode.CHANNELS -> {
                val g = openGroup
                val list = remember(g, channels, visible) {
                    if (g == null) visible else channels.filter { it.group == g }
                }
                ChannelsPanel(
                    modifier = side, title = g ?: "Todos", list = list, current = current,
                    favs = favs, onToggleFav = { toggleFav(it) }, emptyText = null,
                    onLeft = { openPanel(Mode.CATEGORIES, Mode.NONE) }
                ) { l, i -> pick(l, i) }
            }
            Mode.FAVORITES -> ChannelsPanel(
                modifier = side, title = "★  Favoritos", list = favList, current = current,
                favs = favs, onToggleFav = { toggleFav(it) },
                emptyText = "Aún no tienes favoritos.\nEn la barra de abajo elige «Agregar a ★»,\no mantén presionado OK sobre un canal.",
                onLeft = { openPanel(Mode.CATEGORIES, Mode.NONE) }
            ) { l, i -> pick(l, i) }
            Mode.SEARCH -> SearchPanel(
                modifier = side, index = searchIndex, hidden = hidden,
                favs = favs, onToggleFav = { toggleFav(it) }
            ) { l, i -> pick(l, i) }
            Mode.MANAGE -> ManagePanel(
                modifier = side,
                order = order,
                hidden = hidden,
                counts = counts,
                dialogOpen = numberFor != null,
                onMove = { i, d -> order = moveItem(order, i, d); save() },
                onToggle = { g ->
                    hidden = if (g in hidden) hidden - g else hidden + g
                    save()
                },
                onAskNumber = { numberFor = it }
            )
            Mode.SETTINGS -> SettingsPanel(
                modifier = side,
                version = Updater.currentVersion(ctx),
                url = prefs.getString("m3u", "") ?: "",
                bufferLevel = bufferLevel,
                overlaySecs = overlaySecs,
                autoUpdate = autoUpdate,
                updateMsg = updateMsg,
                onBuffer = {
                    bufferLevel = (bufferLevel + 1) % 3
                    prefs.edit().putInt("buffer", bufferLevel).apply()
                },
                onOverlay = {
                    val opts = listOf(3, 5, 8, 12)
                    overlaySecs = opts[(opts.indexOf(overlaySecs).coerceAtLeast(0) + 1) % opts.size]
                    prefs.edit().putInt("overlay_s", overlaySecs).apply()
                },
                onAutoUpdate = {
                    autoUpdate = !autoUpdate
                    prefs.edit().putBoolean("auto_update", autoUpdate).apply()
                },
                onCheckUpdate = onCheckUpdate,
                onReload = onReload,
                onSaveUrl = { if (it.isNotBlank()) onChangeUrl(it) }
            )
        }

        numberFor?.let { g ->
            NumberDialog(g, order.indexOf(g) + 1, order.size, onCancel = { numberFor = null }) { n ->
                order = moveTo(order, g, n - 1)
                save()
                numberFor = null
            }
        }
    }
}

// ---------------- Barra rápida (OK + abajo) ----------------

@Composable
private fun QuickBar(
    isFav: Boolean,
    onSearch: () -> Unit,
    onFavorites: () -> Unit,
    onToggleFav: () -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    val shape = RoundedCornerShape(48.dp)
    Row(
        Modifier
            .clip(shape)
            .background(Color(0xEE0E1322))
            .border(1.dp, Color(0x33FFFFFF), shape)
            .padding(horizontal = 44.dp, vertical = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(48.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        QuickButton(Icons.Default.Search, "Buscar", Modifier.focusRequester(focus), onClick = onSearch)
        QuickButton(Icons.Default.Star, "Favoritos", tint = Gold, onClick = onFavorites)
        QuickButton(
            if (isFav) Icons.Default.Check else Icons.Default.Add,
            if (isFav) "Quitar de ★" else "Agregar a ★",
            tint = if (isFav) Gold else Color.White,
            onClick = onToggleFav
        )
    }
}

@Composable
private fun QuickButton(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.15f else 1f)
    val bg: Brush = if (focused) AccentBrush else SolidColor(Color(0x26FFFFFF))
    Column(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(78.dp).clip(CircleShape).background(bg),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(40.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 18.sp, color = if (focused) Color.White else Gray)
    }
}

// ---------------- Paneles ----------------

@Composable
private fun SidePanel(modifier: Modifier, width: Dp, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxHeight()
            .width(width)
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFA0B0F1A), Color(0xE60B0F1A), Color.Transparent)
                )
            )
            .padding(start = 16.dp, end = 48.dp, top = 24.dp, bottom = 16.dp),
        content = content
    )
}

@Composable
private fun PanelTitle(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp, bottom = 10.dp)) {
        AppLogo(40.dp)
        Spacer(Modifier.width(12.dp))
        Text(text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CategoriesPanel(
    modifier: Modifier,
    groups: List<Pair<String, Int>>,
    total: Int,
    favCount: Int,
    selected: String?,
    onAll: () -> Unit,
    onFavorites: () -> Unit,
    onGroup: (String) -> Unit,
    onSearch: () -> Unit,
    onManage: () -> Unit,
    onSettings: () -> Unit
) {
    val focus = remember { FocusRequester() }
    val selIdx = if (selected == null) 0 else groups.indexOfFirst { it.first == selected } + 2
    val state = rememberLazyListState(initialFirstVisibleItemIndex = selIdx.coerceAtLeast(0))
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    SidePanel(modifier, 700.dp) {
        PanelTitle("MC TV")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(start = 8.dp)) {
            FocusChip("Buscar", onClick = onSearch)
            FocusChip("Editar categorías", onClick = onManage)
            FocusChip("Ajustes", onClick = onSettings)
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(state = state) {
            item {
                CategoryRow(
                    "Todos", total,
                    if (selected == null) Modifier.focusRequester(focus) else Modifier,
                    onAll
                )
            }
            item { CategoryRow("★  Favoritos", favCount, Modifier, onFavorites) }
            itemsIndexed(groups, key = { _, g -> g.first }) { _, g ->
                CategoryRow(
                    g.first, g.second,
                    if (g.first == selected) Modifier.focusRequester(focus) else Modifier
                ) { onGroup(g.first) }
            }
        }
    }
}

@Composable
private fun CategoryRow(title: String, count: Int, modifier: Modifier, onClick: () -> Unit) {
    FocusRow(modifier, onClick) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(12.dp))
        Box(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(Color(0x26FFFFFF))
                .padding(horizontal = 14.dp, vertical = 2.dp)
        ) { Text("$count", fontSize = 17.sp, color = Color.White) }
    }
}

@Composable
private fun ChannelsPanel(
    modifier: Modifier,
    title: String,
    list: List<Channel>,
    current: Channel,
    favs: Set<String>,
    onToggleFav: (Channel) -> Unit,
    emptyText: String?,
    onLeft: () -> Unit,
    onPick: (List<Channel>, Int) -> Unit
) {
    val focus = remember { FocusRequester() }
    val start = list.indexOfFirst { it.url == current.url }.coerceAtLeast(0)
    val state = rememberLazyListState(initialFirstVisibleItemIndex = start)
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    SidePanel(
        modifier.onPreviewKeyEvent { e ->
            if (e.type == KeyEventType.KeyDown && e.key == Key.DirectionLeft) { onLeft(); true } else false
        },
        600.dp
    ) {
        PanelTitle(title)
        if (list.isEmpty()) {
            Text(
                emptyText ?: "No hay canales",
                fontSize = 20.sp, color = Gray,
                modifier = Modifier.padding(start = 8.dp, top = 8.dp)
            )
        } else {
            Text(
                "Mantén presionado OK para agregar o quitar de favoritos",
                fontSize = 15.sp, color = Gray,
                modifier = Modifier.padding(start = 8.dp, bottom = 6.dp)
            )
            LazyColumn(state = state) {
                itemsIndexed(list) { i, ch ->
                    ChannelRow(
                        ch, ch.url in favs,
                        if (i == start) Modifier.focusRequester(focus) else Modifier,
                        { onToggleFav(ch) }
                    ) { onPick(list, i) }
                }
            }
        }
    }
}

@Composable
private fun SearchPanel(
    modifier: Modifier,
    index: List<Pair<Channel, String>>,
    hidden: Set<String>,
    favs: Set<String>,
    onToggleFav: (Channel) -> Unit,
    onPick: (List<Channel>, Int) -> Unit
) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    val results = remember(q, hidden) {
        val tokens = normalize(q).split(" ").filter { it.isNotBlank() }
        if (tokens.isEmpty()) emptyList()
        else index
            .filter { (c, n) -> c.group !in hidden && tokens.all { n.contains(it) } }
            .map { it.first }
            .take(300)
    }

    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !text.isNullOrBlank()) q = text
    }
    fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Di el nombre del canal")
        }
        try {
            voice.launch(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "Este dispositivo no tiene reconocimiento de voz", Toast.LENGTH_LONG).show()
        }
    }

    SidePanel(modifier, 780.dp) {
        PanelTitle("Buscar canal")
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp)) {
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                singleLine = true,
                label = { Text("Nombre del canal") },
                modifier = Modifier.weight(1f).focusRequester(focus)
            )
            Spacer(Modifier.width(12.dp))
            FocusChip("Voz") { startVoice() }
        }
        Spacer(Modifier.height(12.dp))
        when {
            q.isBlank() -> Text("Escribe o dicta el nombre del canal", color = Gray, modifier = Modifier.padding(start = 8.dp))
            results.isEmpty() -> Text("Sin resultados", color = Gray, modifier = Modifier.padding(start = 8.dp))
            else -> LazyColumn {
                itemsIndexed(results) { i, ch ->
                    ChannelRow(ch, ch.url in favs, Modifier, { onToggleFav(ch) }) { onPick(results, i) }
                }
            }
        }
    }
}

@Composable
private fun ManagePanel(
    modifier: Modifier,
    order: List<String>,
    hidden: Set<String>,
    counts: Map<String, Int>,
    dialogOpen: Boolean,
    onMove: (Int, Int) -> Unit,
    onToggle: (String) -> Unit,
    onAskNumber: (String) -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(dialogOpen) { if (!dialogOpen) runCatching { focus.requestFocus() } }

    SidePanel(modifier, 880.dp) {
        PanelTitle("Editar categorías")
        Text(
            "▲ ▼ mueve de a una · Nº la manda a la posición que escribas · Ocultar la esconde",
            fontSize = 16.sp, color = Gray, modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
        )
        LazyColumn {
            itemsIndexed(order, key = { _, g -> g }) { i, g ->
                val isHidden = g in hidden
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${i + 1}", fontSize = 22.sp, fontWeight = FontWeight.Bold,
                        color = Gold, modifier = Modifier.width(48.dp)
                    )
                    Column(Modifier.weight(1f)) {
                        Text(
                            g, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                            color = if (isHidden) Color(0xFF777777) else Color.White
                        )
                        Text("${counts[g] ?: 0} canales", fontSize = 16.sp, color = Gray)
                    }
                    FocusChip("▲", if (i == 0) Modifier.focusRequester(focus) else Modifier) { onMove(i, -1) }
                    Spacer(Modifier.width(8.dp))
                    FocusChip("▼") { onMove(i, 1) }
                    Spacer(Modifier.width(8.dp))
                    FocusChip("Nº") { onAskNumber(g) }
                    Spacer(Modifier.width(8.dp))
                    FocusChip(if (isHidden) "Mostrar" else "Ocultar") { onToggle(g) }
                }
            }
        }
    }
}

@Composable
private fun NumberDialog(
    name: String,
    current: Int,
    total: Int,
    onCancel: () -> Unit,
    onOk: (Int) -> Unit
) {
    var text by remember { mutableStateOf(current.toString()) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    BackHandler { onCancel() }
    fun submit() { text.toIntOrNull()?.let { onOk(it) } }

    Box(
        Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .width(640.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF131827))
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(24.dp))
                .padding(32.dp)
        ) {
            Text("Posición de la carpeta", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(name, fontSize = 20.sp, color = Gold, maxLines = 1)
            Spacer(Modifier.height(10.dp))
            Text(
                "Escribe un número del 1 al $total. El 1 la manda hasta arriba, el 2 al segundo lugar.",
                fontSize = 18.sp, color = Gray
            )
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { v -> text = v.filter { it.isDigit() }.take(4) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                modifier = Modifier.width(200.dp).focusRequester(focus)
            )
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                FocusChip("Aceptar") { submit() }
                FocusChip("Cancelar") { onCancel() }
            }
        }
    }
}

@Composable
private fun SettingsPanel(
    modifier: Modifier,
    version: String,
    url: String,
    bufferLevel: Int,
    overlaySecs: Int,
    autoUpdate: Boolean,
    updateMsg: String?,
    onBuffer: () -> Unit,
    onOverlay: () -> Unit,
    onAutoUpdate: () -> Unit,
    onCheckUpdate: () -> Unit,
    onReload: () -> Unit,
    onSaveUrl: (String) -> Unit
) {
    val focus = remember { FocusRequester() }
    var text by remember { mutableStateOf(url) }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    val labels = listOf("Bajo", "Normal", "Alto")

    SidePanel(modifier, 780.dp) {
        PanelTitle("Ajustes")
        SettingRow("Buffer del video", labels[bufferLevel.coerceIn(0, 2)], Modifier.focusRequester(focus), onBuffer)
        SettingRow("Duración de la barra de info", "$overlaySecs s", onClick = onOverlay)
        SettingRow("Buscar actualizaciones al abrir", if (autoUpdate) "Sí" else "No", onClick = onAutoUpdate)
        SettingRow("Buscar actualización ahora", updateMsg ?: "Versión $version", onClick = onCheckUpdate)
        SettingRow("Recargar lista de canales", "", onClick = onReload)
        Spacer(Modifier.height(16.dp))
        Text("Lista M3U", fontSize = 18.sp, color = Gray, modifier = Modifier.padding(start = 8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp)) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(12.dp))
            FocusChip("Guardar") { onSaveUrl(text.trim()) }
        }
    }
}

@Composable
private fun SettingRow(label: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FocusRow(modifier, onClick) {
        Text(label, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (value.isNotEmpty()) Text(value, fontSize = 20.sp, color = Gray)
    }
}

// ---------------- Componentes ----------------

@Composable
private fun FocusChip(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.08f else 1f)
    val bg: Brush = if (focused) AccentBrush else SolidColor(Color(0x33FFFFFF))
    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(50))
            .background(bg)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) { Text(text, fontSize = 18.sp, color = Color.White) }
}

@Composable
private fun FocusRow(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onLongPress: (() -> Unit)? = null,
    content: @Composable RowScope.(Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    var longDone by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.02f else 1f)
    val shape = RoundedCornerShape(40.dp)
    val bg: Brush = if (focused) AccentBrush else SolidColor(Color(0x14FFFFFF))
    Row(
        modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                transformOrigin = TransformOrigin(0f, 0.5f)
            }
            .clip(shape)
            .background(bg)
            .then(if (focused) Modifier.border(2.dp, Color(0x66FFFFFF), shape) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .onPreviewKeyEvent { e ->
                if (onLongPress == null) return@onPreviewKeyEvent false
                val ok = e.key == Key.DirectionCenter || e.key == Key.Enter
                if (!ok) return@onPreviewKeyEvent false
                when (e.type) {
                    KeyEventType.KeyDown ->
                        if (e.nativeKeyEvent.repeatCount > 0) {
                            if (!longDone) { longDone = true; onLongPress() }
                            true
                        } else false
                    KeyEventType.KeyUp ->
                        if (longDone) { longDone = false; true } else false
                    else -> false
                }
            }
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) { this.content(focused) }
}

@Composable
private fun ChannelRow(
    ch: Channel,
    fav: Boolean,
    modifier: Modifier = Modifier,
    onLong: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    FocusRow(modifier, onClick, onLong) {
        Logo(ch.logo, 60.dp)
        Spacer(Modifier.width(20.dp))
        Column(Modifier.weight(1f)) {
            Text(ch.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("Sin información", fontSize = 18.sp, color = Gray, maxLines = 1)
        }
        if (fav) {
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.Star, contentDescription = "Favorito", tint = Gold, modifier = Modifier.size(28.dp))
        }
    }
}

@Composable
fun Clock(modifier: Modifier = Modifier) {
    val fmt = remember { SimpleDateFormat("hh:mm a - EEE, d MMM yyyy", Locale("es", "MX")) }
    var now by remember { mutableStateOf(fmt.format(Date())) }
    LaunchedEffect(Unit) {
        while (true) { now = fmt.format(Date()); delay(15000) }
    }
    Pill(now, modifier, 22.sp)
}

@Composable
fun Pill(text: String, modifier: Modifier = Modifier, size: TextUnit = 18.sp) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0x99000000))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(50))
            .padding(horizontal = 18.dp, vertical = 8.dp)
    ) { Text(text, fontSize = size, color = Color.White) }
}

@Composable
fun Logo(url: String?, size: Dp) {
    val shape = RoundedCornerShape(size / 6)
    Box(
        Modifier
            .size(size)
            .clip(shape)
            .background(Color.White)
            .border(1.dp, Color(0x33FFFFFF), shape)
            .padding(size / 14),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = url,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun PlayerOverlay(ch: Channel, res: String, fav: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF2070A12))))
            .padding(horizontal = 36.dp, vertical = 28.dp)
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Logo(ch.logo, 116.dp)
            Spacer(Modifier.width(26.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ch.number?.let {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(AccentBrush)
                                .padding(horizontal = 12.dp, vertical = 3.dp)
                        ) { Text(it, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp))
                    }
                    Text(
                        "${ch.group} • ${ch.name}",
                        fontSize = 22.sp, color = Gray, fontWeight = FontWeight.Bold, maxLines = 1
                    )
                }
                Text("Sin información", fontSize = 38.sp, fontWeight = FontWeight.Medium)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (fav) Icon(Icons.Default.Star, contentDescription = "Favorito", tint = Gold, modifier = Modifier.size(32.dp))
                if (res.isNotEmpty()) Pill(res)
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0x33FF4D4D))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(Red))
                    Spacer(Modifier.width(8.dp))
                    Text("EN VIVO", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}
