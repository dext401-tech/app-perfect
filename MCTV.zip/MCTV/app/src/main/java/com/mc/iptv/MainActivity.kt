package com.mc.iptv

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.SharedPreferences
import android.view.KeyEvent
import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.media3.common.MimeTypes
import android.view.WindowManager
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import kotlin.math.abs
import androidx.compose.ui.zIndex
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.media3.common.TrackSelectionOverride
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import java.io.File
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Tracks
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.ui.PlayerView
import coil.Coil
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.ImageRequest
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private class ThemeDef(val name: String, val base: Color, val card: Color, val card2: Color, val tint: Color)
private val themeDefs = listOf(
    ThemeDef("Medianoche", Color(0xFF0B0F1A), Color(0xFF131827), Color(0xFF1A2033), Color(0xFF1B1440)),
    ThemeDef("Negro profundo", Color(0xFF000000), Color(0xFF0A0A0A), Color(0xFF141414), Color(0xFF000000)),
    ThemeDef("Grafito", Color(0xFF121214), Color(0xFF1C1C20), Color(0xFF26262B), Color(0xFF22222A)),
    ThemeDef("Bosque", Color(0xFF07120D), Color(0xFF0E1D16), Color(0xFF14291F), Color(0xFF0B2A1C)),
    ThemeDef("Vino", Color(0xFF140A10), Color(0xFF1E1018), Color(0xFF2A1722), Color(0xFF2B0F1F))
)
private val accentDefs = listOf(
    Triple("Azul y violeta", Color(0xFF3B82F6), Color(0xFF8B5CF6)),
    Triple("Cian", Color(0xFF06B6D4), Color(0xFF3B82F6)),
    Triple("Verde", Color(0xFF10B981), Color(0xFF84CC16)),
    Triple("Naranja", Color(0xFFF97316), Color(0xFFEF4444)),
    Triple("Rosa", Color(0xFFEC4899), Color(0xFF8B5CF6)),
    Triple("Dorado", Color(0xFFF59E0B), Color(0xFFEAB308)),
    Triple("Blanco", Color(0xFFE5E7EB), Color(0xFF9CA3AF))
)
private object LogoDiag {
    var fails by mutableIntStateOf(0)
    var last by mutableStateOf("")
}
private object Th {
    var themeIdx by mutableIntStateOf(0)
    var accentIdx by mutableIntStateOf(0)
    val theme: ThemeDef get() = themeDefs[themeIdx.coerceIn(0, themeDefs.size - 1)]
}
private fun bg(a: Float): Color = Th.theme.base.copy(alpha = a)
private val Blue: Color get() = accentDefs[Th.accentIdx.coerceIn(0, accentDefs.size - 1)].second
private val Violet: Color get() = accentDefs[Th.accentIdx.coerceIn(0, accentDefs.size - 1)].third
private val Gold = Color(0xFFFFC857)
private val Gray = Color(0xFFB0B0B0)
private val Red = Color(0xFFFF4D4D)
private val AccentBrush: Brush get() = Brush.horizontalGradient(listOf(Blue, Violet))
private val accents = Regex("\\p{Mn}+")
private const val CAT_ALL = "§todos"

private enum class Kind { LIVE, MOVIE, SERIES }

// Clasifica cada entrada de la lista por su URL (las listas Xtream usan /movie/ y /series/)
private fun kindOf(c: Channel): Kind {
    val u = c.url.substringBefore('?').lowercase()
    return when {
        "/movie/" in u -> Kind.MOVIE
        "/series/" in u -> Kind.SERIES
        u.endsWith(".mp4") || u.endsWith(".mkv") || u.endsWith(".avi") || u.endsWith(".mov") || u.endsWith(".m4v") -> Kind.MOVIE
        else -> Kind.LIVE
    }
}

private class Show(val title: String, val logo: String?, val group: String, val episodes: List<Channel>)
private class PosterItem(val name: String, val logo: String?, val payload: Any)
private class Resume(val url: String, val pos: Long, val dur: Long)

private val epPattern = Regex("(?i)\\s*[-–:|]?\\s*(s\\s?\\d{1,2}\\s?[-._ ]?\\s?e\\s?\\d{1,3}|\\d{1,2}x\\d{1,3}|t\\s?\\d{1,2}\\s?[-._ ]?\\s?e\\s?\\d{1,3}|temporada\\s?\\d+|cap[ií]tulo\\s?\\d+|episodio\\s?\\d+).*$")

private fun showTitle(name: String): String = name.replace(epPattern, "").trim().ifBlank { name.trim() }

private fun buildShows(eps: List<Channel>): List<Show> {
    val map = LinkedHashMap<String, MutableList<Channel>>()
    for (c in eps) map.getOrPut(c.group + "\u0001" + showTitle(c.name)) { ArrayList() }.add(c)
    return map.values.map { v ->
        Show(
            showTitle(v[0].name),
            v.firstNotNullOfOrNull { it.logo?.takeIf { l -> l.isNotBlank() } },
            v[0].group,
            v.sortedBy { it.name.lowercase() }
        )
    }
}

private fun readResume(prefs: SharedPreferences): List<Resume> =
    (prefs.getString("resume", "") ?: "").split("\n").mapNotNull { l ->
        val p = l.split("\t")
        if (p.size < 3) null else {
            val a = p[1].toLongOrNull()
            val b = p[2].toLongOrNull()
            if (a == null || b == null) null else Resume(p[0], a, b)
        }
    }

// Guarda en qué minuto vas (se borra si ya la terminaste o llevas menos de 30 s)
private fun saveResume(prefs: SharedPreferences, url: String, pos: Long, dur: Long) {
    val cur = readResume(prefs).filter { it.url != url }
    val finished = dur > 0 && pos > dur * 0.95
    val out = if (finished || pos < 30_000L) cur else listOf(Resume(url, pos, dur)) + cur
    prefs.edit().putString("resume", out.take(40).joinToString("\n") { "${it.url}\t${it.pos}\t${it.dur}" }).apply()
}

private fun trackLabel(f: androidx.media3.common.Format, n: Int): String {
    val lang = f.language?.let { java.util.Locale.forLanguageTag(it).getDisplayLanguage(java.util.Locale("es")) }
        ?.takeIf { it.isNotBlank() }
    val lab = f.label?.takeIf { it.isNotBlank() && it != lang }
    return listOfNotNull(lang, lab).joinToString(" · ").ifBlank { "Pista $n" }
}

private fun fmtTime(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0)
    val h = t / 3600
    val m = (t % 3600) / 60
    val sec = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}
private const val CAT_FAV = "§favoritos"
private const val CACHE_MAX_AGE_MS = 12L * 60 * 60 * 1000

private enum class Mode { NONE, QUICK, CATEGORIES, CHANNELS, FAVORITES, SEARCH, MANAGE, SETTINGS, LISTS, MOVIES, SERIES, EPISODES, VODSEARCH, VODOPTS, VODTRACKS }

class MainActivity : ComponentActivity() {
    // Lo registra la pantalla del reproductor: recibe (esDown) y devuelve true si ya atendió el Atrás
    var backInterceptor: ((Boolean) -> Boolean)? = null

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            val h = backInterceptor
            if (h != null && h(event.action == KeyEvent.ACTION_DOWN)) return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val crashFile = java.io.File(filesDir, "crash.txt")
        val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { crashFile.writeText(android.util.Log.getStackTraceString(e).take(3500)) }
            prevHandler?.uncaughtException(t, e)
        }
        val lastCrash = runCatching { if (crashFile.exists()) crashFile.readText() else null }.getOrNull()
        if (lastCrash != null) {
            setContent {
                Column(Modifier.fillMaxSize().background(Color(0xFF200000)).padding(24.dp)) {
                    Text("MC TV se cerró por un error (manda foto de esto)", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(lastCrash, color = Color(0xFFFFB4B4), fontSize = 12.sp, modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()))
                    FocusChip("Borrar error y abrir la app") {
                        runCatching { crashFile.delete() }
                        recreate()
                    }
                }
            }
            return
        }
        // En celular: pantalla horizontal, completa y que no se apague mientras ves TV
        val isTv = (getSystemService(UI_MODE_SERVICE) as android.app.UiModeManager).currentModeType ==
            android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
        if (!isTv) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        androidx.core.view.WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        // Cargador de logos: más descargas a la vez, caché en disco y sin depender de los encabezados del servidor
        val dispatcher = Dispatcher().apply { maxRequests = 32; maxRequestsPerHost = 12 }
        val http = OkHttpClient.Builder()
            .dispatcher(dispatcher)
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
            .addInterceptor { chain ->
                chain.proceed(
                    chain.request().newBuilder()
                        .header("User-Agent", "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                        .header("Accept", "image/png,image/jpeg,image/webp,image/*;q=0.8,*/*;q=0.5")
                        .build()
                )
            }
            .retryOnConnectionFailure(true)
            .build()
        Coil.setImageLoader(
            ImageLoader.Builder(this)
                .okHttpClient(http)
                .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.20).build() }
                .diskCache { DiskCache.Builder().directory(cacheDir.resolve("logos")).maxSizeBytes(150L * 1024 * 1024).build() }
                .respectCacheHeaders(false)
                .crossfade(true)
                .build()
        )
        runCatching {
            val sp = getSharedPreferences("mctv", 0)
            Th.themeIdx = sp.getInt("theme", 0).coerceIn(0, themeDefs.size - 1)
            Th.accentIdx = sp.getInt("accent", 0).coerceIn(0, accentDefs.size - 1)
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Blue, secondary = Violet, background = Th.theme.base, surface = Th.theme.card)) {
                Surface(Modifier.fillMaxSize(), color = Th.theme.base, contentColor = Color.White) {
                    App()
                }
            }
        }
    }
}

private fun download(url: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 15000
    c.readTimeout = 30000
    c.setRequestProperty("User-Agent", "MCTV/0.4")
    return c.inputStream.bufferedReader().use { it.readText() }
}

// Descarga la lista, la guarda en la TV y la va procesando mientras baja (sin esperar a tenerla completa)
private fun fetchPlaylist(url: String, cacheFile: File, onProgress: (Long) -> Unit): List<Channel> {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 15000
    c.readTimeout = 30000
    c.setRequestProperty("User-Agent", "MCTV/0.7")
    val tmp = File(cacheFile.parentFile, "playlist-${System.nanoTime()}.tmp")
    try {
        var bytes = 0L
        var last = 0L
        val list = tmp.bufferedWriter().use { w ->
            c.inputStream.bufferedReader().useLines { lines ->
                M3uParser.parse(lines.map { line ->
                    w.write(line)
                    w.write("\n")
                    bytes += line.length + 1
                    if (bytes - last > 262144L) { last = bytes; onProgress(bytes) }
                    line
                })
            }
        }
        if (list.isNotEmpty()) {
            cacheFile.delete()
            tmp.renameTo(cacheFile)
        }
        return list
    } finally {
        c.disconnect()
        tmp.delete()
    }
}

private fun normalize(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD).replace(accents, "").lowercase(Locale.ROOT)

private fun mergeOrder(saved: String, all: List<String>): List<String> {
    val set = all.toSet()
    val s = saved.split("\n").filter { it in set }
    val seen = s.toSet()
    return s + all.filter { it !in seen }
}

private fun moveItem(list: List<String>, i: Int, d: Int): List<String> {
    val j = i + d
    if (j !in list.indices) return list
    val m = list.toMutableList()
    val t = m[i]; m[i] = m[j]; m[j] = t
    return m
}

private fun moveTo(list: List<String>, g: String, pos: Int): List<String> {
    val m = list.toMutableList()
    if (!m.remove(g)) return list
    m.add(pos.coerceIn(0, m.size), g)
    return m
}

// ---------------- Listas guardadas ----------------

private fun loadLists(prefs: SharedPreferences): List<Pair<String, String>> {
    val out = (prefs.getString("lists", "") ?: "").split("\n")
        .mapNotNull { l ->
            val i = l.indexOf('\t')
            if (i <= 0) null else l.substring(0, i) to l.substring(i + 1)
        }
    val active = prefs.getString("m3u", "") ?: ""
    // Si ya tenías una lista de antes, se guarda como "Lista 1"
    if (out.isEmpty() && active.isNotBlank()) return listOf("Lista 1" to active)
    return out
}

private fun saveLists(prefs: SharedPreferences, lists: List<Pair<String, String>>) {
    prefs.edit().putString("lists", lists.joinToString("\n") { "${it.first.replace('\t', ' ').replace('\n', ' ')}\t${it.second}" }).apply()
}

private fun addList(prefs: SharedPreferences, name: String, url: String): List<Pair<String, String>> {
    val cur = loadLists(prefs).toMutableList()
    val i = cur.indexOfFirst { it.second == url }
    val n = name.trim().ifBlank { if (i >= 0) cur[i].first else "Lista ${cur.size + 1}" }
    if (i >= 0) cur[i] = n to url else cur.add(n to url)
    saveLists(prefs, cur)
    return cur
}

private fun cacheFileFor(ctx: android.content.Context, url: String) =
    File(ctx.filesDir, "pl_${url.hashCode().toUInt()}.m3u")

// Copia compacta de la lista ya procesada: se lee en una fracción de segundo (el .m3u tarda mucho más en procesarse)
private fun binFor(cacheFile: File) = File(cacheFile.path.removeSuffix(".m3u") + ".bin")

private fun writeBin(cacheFile: File, list: List<Channel>) {
    val bin = binFor(cacheFile)
    val tmp = File(bin.path + ".tmp")
    try {
        java.io.DataOutputStream(java.io.BufferedOutputStream(tmp.outputStream(), 1 shl 16)).use { o ->
            o.writeInt(list.size)
            for (c in list) {
                o.writeUTF(c.name); o.writeUTF(c.url); o.writeUTF(c.logo ?: "")
                o.writeUTF(c.group); o.writeUTF(c.number ?: "")
            }
        }
        bin.delete()
        tmp.renameTo(bin)
    } catch (e: Exception) {
        tmp.delete()
        bin.delete()
    }
}

private fun readBin(cacheFile: File): List<Channel>? {
    val bin = binFor(cacheFile)
    if (!bin.exists() || bin.lastModified() < cacheFile.lastModified()) return null
    return try {
        java.io.DataInputStream(java.io.BufferedInputStream(bin.inputStream(), 1 shl 16)).use { i ->
            val n = i.readInt()
            val out = ArrayList<Channel>(n)
            repeat(n) {
                val name = i.readUTF(); val url = i.readUTF(); val logo = i.readUTF()
                val group = i.readUTF(); val num = i.readUTF()
                out.add(Channel(name, url, logo.ifEmpty { null }, group, num.ifEmpty { null }))
            }
            out
        }
    } catch (e: Exception) { null }
}

private fun hostOf(u: String) = u.substringAfter("://").substringBefore("/").substringBefore("?")

// ---------------- App ----------------

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("mctv", 0) }
    var url by remember { mutableStateOf(prefs.getString("m3u", "") ?: "") }
    var reload by remember { mutableIntStateOf(0) }
    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var update by remember { mutableStateOf<UpdateInfo?>(null) }
    var updateMsg by remember { mutableStateOf<String?>(null) }

    var force by remember { mutableStateOf(false) }
    // Arranque rápido: el último canal empieza a reproducirse mientras la lista completa se abre en segundo plano
    var bootQuick by remember { mutableStateOf(true) }
    val quickCh = remember {
        val u = prefs.getString("last_url", null)
        val n = prefs.getString("last_name", null)
        if (!u.isNullOrBlank() && n != null)
            Channel(n, u, prefs.getString("last_logo", "")?.ifBlank { null }, prefs.getString("last_group", "") ?: "", null)
        else null
    }
    val showPlayer = channels.isNotEmpty() || (bootQuick && quickCh != null && url.isNotBlank() && error == null)
    var progress by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(url, reload) {
        if (url.isBlank()) return@LaunchedEffect
        loading = true
        error = null
        progress = null
        val cacheFile = cacheFileFor(ctx, url)
        // Migración: la lista guardada por versiones anteriores
        val old = File(ctx.filesDir, "playlist.m3u")
        if (!cacheFile.exists() && old.exists() && prefs.getString("cache_url", "") == url) old.copyTo(cacheFile, overwrite = true)
        val useCache = !force && cacheFile.exists()
        if (useCache) {
            // Lista guardada en la TV: abre al instante, sin esperar a internet
            progress = "Abriendo la lista guardada..."
            val stale = System.currentTimeMillis() - cacheFile.lastModified() > CACHE_MAX_AGE_MS
            val cached = try {
                withContext(Dispatchers.IO) {
                    readBin(cacheFile) ?: cacheFile.bufferedReader().useLines { M3uParser.parse(it) }.also {
                        if (it.isNotEmpty()) writeBin(cacheFile, it) // la próxima vez abre mucho más rápido
                    }
                }
            } catch (e: Exception) { emptyList() }
            if (cached.isNotEmpty()) {
                channels = cached
                loading = false
                progress = null
                // Si la lista guardada tiene más de 12 h se actualiza en segundo plano
                if (stale) {
                    scope.launch(Dispatchers.IO) {
                        runCatching { writeBin(cacheFile, fetchPlaylist(url, cacheFile) { }) }
                    }
                }
                return@LaunchedEffect
            }
        }
        try {
            progress = "Descargando lista..."
            val list = withContext(Dispatchers.IO) {
                fetchPlaylist(url, cacheFile) { bytes ->
                    progress = "Descargando lista... " + "%.1f".format(Locale.US, bytes / 1048576.0) + " MB"
                }.also { if (it.isNotEmpty()) writeBin(cacheFile, it) }
            }
            if (list.isEmpty()) {
                error = "La lista no tiene canales"
            } else {
                prefs.edit().putString("cache_url", url).apply()
                channels = list
            }
        } catch (e: Exception) {
            error = e.message ?: "Error al cargar la lista"
        }
        force = false
        loading = false
        progress = null
    }

    // Buscar actualización al abrir (si está activado en Ajustes)
    LaunchedEffect(Unit) {
        if (prefs.getBoolean("auto_update", true)) {
            try {
                update = Updater.check(ctx)
            } catch (e: IllegalStateException) {
                updateMsg = e.message
            } catch (_: Exception) {}
        }
    }

    fun checkNow() {
        updateMsg = "Buscando..."
        scope.launch {
            try {
                val u = Updater.check(ctx)
                if (u != null) { update = u; updateMsg = null } else updateMsg = "Ya tienes la última"
            } catch (e: IllegalStateException) {
                updateMsg = e.message ?: "No se pudo buscar"
                Toast.makeText(ctx, updateMsg, Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                updateMsg = "Sin conexión a internet"
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!showPlayer && url.isNotBlank() && error == null) {
            // Ya hay una lista guardada: solo pantalla de carga, sin pedir la lista
            Splash(progress)
        } else if (!showPlayer) {
            SetupScreen(url, loading, error, progress) { name, link ->
                addList(prefs, name, link)
                prefs.edit().putString("m3u", link).apply()
                force = true
                bootQuick = false
                url = link
                reload++
            }
        } else {
            PlayerScreen(
                allChannels = if (channels.isNotEmpty()) channels else listOf(quickCh!!),
                prefs = prefs,
                dialogOpen = update != null,
                updateMsg = updateMsg,
                onCheckUpdate = { checkNow() },
                onChangeUrl = {
                    prefs.edit().putString("m3u", it).apply()
                    force = false // si esa lista ya estaba guardada en la TV, abre al instante
                    bootQuick = false
                    channels = emptyList()
                    url = it
                    reload++
                },
                onReload = {
                    force = true
                    bootQuick = false
                    channels = emptyList()
                    reload++
                },
                onNewList = { name, link ->
                    addList(prefs, name, link)
                    prefs.edit().putString("m3u", link).apply()
                    force = true
                    bootQuick = false
                    channels = emptyList()
                    url = link
                    reload++
                }
            )
        }

        update?.let { UpdateDialog(it) { update = null } }
    }
}

@Composable
fun AppLogo(size: Dp) {
    Image(
        painter = painterResource(R.drawable.logo),
        contentDescription = null,
        modifier = Modifier.size(size).clip(RoundedCornerShape(size / 5))
    )
}

@Composable
private fun UpdateDialog(info: UpdateInfo, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var progress by remember { mutableStateOf<Int?>(null) }
    var msg by remember { mutableStateOf<String?>(null) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    BackHandler { onDismiss() }

    fun start() {
        if (!Updater.canInstall(ctx)) {
            msg = "Activa «Instalar apps desconocidas» para MC TV y vuelve a tocar Actualizar"
            try {
                Updater.openInstallPermission(ctx)
            } catch (e: Exception) {
                Toast.makeText(ctx, "Abre Ajustes de la TV y permite instalar apps desconocidas", Toast.LENGTH_LONG).show()
            }
            return
        }
        progress = 0
        scope.launch {
            try {
                val f = Updater.download(ctx, info.apkUrl) { progress = it }
                progress = null
                Updater.install(ctx, f)
            } catch (e: Exception) {
                progress = null
                msg = "No se pudo descargar: ${e.message}"
            }
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .width(640.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Th.theme.card)
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(24.dp))
                .padding(32.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppLogo(64.dp)
                Spacer(Modifier.width(18.dp))
                Column {
                    Text("Nueva versión ${info.version}", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("Tienes la ${Updater.currentVersion(ctx)}", fontSize = 20.sp, color = Gray)
                }
            }
            msg?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, fontSize = 18.sp, color = Gold)
            }
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                FocusChip(
                    if (progress != null) "Descargando ${progress}%" else "Actualizar",
                    Modifier.focusRequester(focus)
                ) { if (progress == null) start() }
                FocusChip("Después") { onDismiss() }
            }
        }
    }
}

@Composable
private fun Splash(status: String?) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Th.theme.base, Th.theme.tint))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AppLogo(140.dp)
            Spacer(Modifier.height(16.dp))
            Text("MC TV", fontSize = 40.sp, fontWeight = FontWeight.Bold)
            if (status != null) {
                Spacer(Modifier.height(12.dp))
                Text(status, fontSize = 18.sp, color = Gray)
            }
        }
    }
}

@Composable
fun SetupScreen(initial: String, loading: Boolean, error: String?, status: String?, onLoad: (String, String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    var listName by remember { mutableStateOf("") }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Th.theme.base, Th.theme.tint)))
    ) {
        Column(
            Modifier.fillMaxSize().padding(80.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AppLogo(140.dp)
            Spacer(Modifier.height(20.dp))
            Text("MC TV", fontSize = 44.sp, fontWeight = FontWeight.Bold)
            Text("Tu televisión en vivo", fontSize = 20.sp, color = Gray)
            Spacer(Modifier.height(32.dp))
            OutlinedTextField(
                value = listName,
                onValueChange = { listName = it },
                label = { Text("Nombre de la lista (opcional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(0.7f)
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("URL de tu lista M3U") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(0.7f)
            )
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(onClick = { onLoad(listName.trim(), text.trim()) }, enabled = !loading && text.isNotBlank()) {
                    Text(if (loading) "Cargando..." else "Cargar lista")
                }
                Button(onClick = { text = ""; listName = "" }, enabled = !loading) { Text("Limpiar") }
            }
            if (loading && status != null) {
                Spacer(Modifier.height(16.dp))
                Text(status, fontSize = 20.sp, color = Gray)
            }
            error?.let {
                Spacer(Modifier.height(16.dp))
                Text(it, color = Color(0xFFFF6B6B))
            }
        }
    }
}

// ---------------- Reproductor ----------------

// Le dice al reproductor qué tipo de stream es, para que no pierda tiempo adivinándolo
private fun mediaItemFor(url: String): MediaItem {
    val path = url.substringBefore('?').lowercase()
    val b = MediaItem.Builder().setUri(url)
    if (path.endsWith(".m3u8")) b.setMimeType(MimeTypes.APPLICATION_M3U8)
    else if (path.endsWith(".ts")) b.setMimeType(MimeTypes.VIDEO_MP2T)
    return b.build()
}

private fun buildPlayer(ctx: android.content.Context, level: Int, small: Boolean): ExoPlayer {
    // minimo, maximo, para empezar a reproducir, para reanudar tras un corte (ms)
    // Con precarga el buffer es corto para que el canal precargado no llegue atrasado
    val (minMs, maxMs, startMs, reMs) = if (small) listOf(3000, 6000, 500, 1500) else when (level) {
        0 -> listOf(8000, 20000, 500, 2000)
        2 -> listOf(30000, 60000, 1500, 4000)
        else -> listOf(20000, 40000, 800, 3000)
    }
    val http = DefaultHttpDataSource.Factory()
        .setConnectTimeoutMs(15000)
        .setReadTimeoutMs(15000)
        .setAllowCrossProtocolRedirects(true)
    val load = DefaultLoadControl.Builder()
        .setBufferDurationsMs(minMs, maxMs, startMs, reMs)
        .setPrioritizeTimeOverSizeThresholds(true)
        .setBackBuffer(0, false)
        .build()
    val extractors = DefaultExtractorsFactory().setTsExtractorFlags(
        DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
            DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
    )
    return ExoPlayer.Builder(ctx)
        .setMediaSourceFactory(DefaultMediaSourceFactory(http, extractors))
        .setLoadControl(load)
        .build()
}

@Composable
private fun PlayerScreen(
    allChannels: List<Channel>,
    prefs: SharedPreferences,
    dialogOpen: Boolean,
    updateMsg: String?,
    onCheckUpdate: () -> Unit,
    onChangeUrl: (String) -> Unit,
    onReload: () -> Unit,
    onNewList: (String, String) -> Unit
) {
    val ctx = LocalContext.current

    // TV en vivo / películas / series se separan por el tipo de URL
    val channels = remember(allChannels) { allChannels.filter { kindOf(it) == Kind.LIVE }.ifEmpty { allChannels } }
    val movies = remember(allChannels) { allChannels.filter { kindOf(it) == Kind.MOVIE } }
    val seriesList = remember(allChannels) { allChannels.filter { kindOf(it) == Kind.SERIES } }
    val shows = remember(seriesList) { buildShows(seriesList) }
    val byUrl = remember(allChannels) { lazy { allChannels.associateBy { it.url } } }
    val epToShow = remember(shows) {
        lazy { HashMap<String, Show>().also { m -> shows.forEach { sh -> sh.episodes.forEach { m[it.url] = sh } } } }
    }

    // ---- Ajustes (se guardan en prefs) ----
    var bufferLevel by remember { mutableIntStateOf(prefs.getInt("buffer", 1)) }
    var overlaySecs by remember { mutableIntStateOf(prefs.getInt("overlay_s", 5)) }
    var autoUpdate by remember { mutableStateOf(prefs.getBoolean("auto_update", true)) }
    var scrubSpeed by remember { mutableIntStateOf(prefs.getInt("scrub_speed", 1)) }

    var lists by remember { mutableStateOf(loadLists(prefs)) }
    var preload by remember { mutableStateOf(prefs.getBoolean("preload", false)) }
    var preferTs by remember { mutableStateOf(prefs.getBoolean("prefer_ts", false)) }
    var keepFrame by remember { mutableStateOf(prefs.getBoolean("keep_frame", true)) }
    var subsOn by remember { mutableStateOf(prefs.getBoolean("subs", false)) }
    var hasText by remember { mutableStateOf(false) }      // el canal trae subtítulos
    var vodPaused by remember { mutableStateOf(false) }
    var openShow by remember { mutableStateOf<Show?>(null) }
    var vodTick by remember { mutableIntStateOf(0) }
    var pip by remember { mutableStateOf(false) } // la película se ve en miniatura arriba a la derecha
    var scrubPos by remember { mutableStateOf<Long?>(null) } // posición a la que te estás moviendo en la línea de tiempo
    val scrubState = remember { longArrayOf(0L, 0L) }         // [distancia recorrida, hora de la última pulsación]
    var trackKind by remember { mutableIntStateOf(0) }        // 0 = idioma, 1 = subtítulos
    val barFocus = remember { FocusRequester() }
    var vodSpeed by remember { mutableFloatStateOf(1f) }
    var lastLive by remember { mutableStateOf<Channel?>(null) }
    var aspect by remember { mutableIntStateOf(prefs.getInt("aspect", 0)) } // 0 normal, 1 llenar, 2 estirar

    // Reproductores: 1 normal, o 3 (el de en medio + vecino de arriba + vecino de abajo) si activas la precarga.
    // Se vuelven a crear si cambias el buffer o la precarga.
    val pool = remember(bufferLevel, preload) { List(if (preload) 3 else 1) { buildPlayer(ctx, bufferLevel, preload) } }
    val slotUrl = remember(pool) { arrayOfNulls<String>(pool.size) }
    var active by remember(pool) { mutableIntStateOf(0) }
    val player = pool[active]

    fun streamUrl(c: Channel): String =
        if (preferTs && c.url.endsWith(".m3u8", ignoreCase = true)) c.url.dropLast(5) + ".ts" else c.url

    // Medición de tiempos de arranque (para saber qué canales tardan)
    var lastError by remember { mutableStateOf("") }
    var zapStart by remember { mutableLongStateOf(0L) }
    var zapLast by remember { mutableLongStateOf(0L) }
    var zapSum by remember { mutableLongStateOf(0L) }
    var zapN by remember { mutableIntStateOf(0) }
    var zapWorst by remember { mutableLongStateOf(0L) }
    var zapWorstName by remember { mutableStateOf("") }
    val nameHolder = remember { arrayOf("") }

    // ---- Categorías: orden y ocultas (se guardan en prefs) ----
    val allGroups = remember(channels) { channels.map { it.group }.distinct() }
    val counts = remember(channels) { channels.groupingBy { it.group }.eachCount() }
    val searchIndex by produceState(emptyList<Pair<Channel, String>>(), channels) {
        value = withContext(Dispatchers.Default) { channels.map { it to normalize(it.name) } }
    }
    val vodIndex by produceState(emptyList<Pair<Channel, String>>(), allChannels) {
        value = withContext(Dispatchers.Default) {
            allChannels.filter { kindOf(it) != Kind.LIVE }.map { it to normalize(it.name) }
        }
    }
    var order by remember(allGroups) {
        mutableStateOf(mergeOrder(prefs.getString("cat_order", "") ?: "", allGroups))
    }
    var hidden by remember(allGroups) {
        mutableStateOf((prefs.getStringSet("cat_hidden", emptySet()) ?: emptySet()).toSet())
    }
    fun save() {
        prefs.edit()
            .putString("cat_order", order.joinToString("\n"))
            .putStringSet("cat_hidden", hidden.toSet())
            .apply()
    }
    val visible = remember(channels, hidden) {
        channels.filter { it.group !in hidden }.ifEmpty { channels }
    }

    // ---- Favoritos (se guardan por URL del canal) ----
    var favs by remember { mutableStateOf((prefs.getStringSet("favs", emptySet()) ?: emptySet()).toSet()) }
    fun toggleFav(c: Channel) {
        favs = if (c.url in favs) favs - c.url else favs + c.url
        prefs.edit().putStringSet("favs", favs.toSet()).apply()
    }
    val favList = remember(channels, favs) { channels.filter { it.url in favs } }
    val byGroup = remember(channels) { channels.groupBy { it.group } }

    // ---- Reproducción ----
    val lastUrl = remember { prefs.getString("last_url", null) }
    val initial = remember(channels) {
        val iv = visible.indexOfFirst { it.url == lastUrl }
        if (iv >= 0) visible to iv
        else {
            val ia = channels.indexOfFirst { it.url == lastUrl }
            if (ia >= 0) channels to ia else visible to 0
        }
    }
    var playlist by remember { mutableStateOf(initial.first) }
    var index by remember { mutableIntStateOf(initial.second) }
    val current = playlist.getOrNull(index) ?: channels.first()
    nameHolder[0] = current.name
    val isVod = kindOf(current) != Kind.LIVE
    val isVodNow by rememberUpdatedState(isVod)
    val visibleNow by rememberUpdatedState(visible)
    LaunchedEffect(current.url) { if (!isVod) lastLive = current }

    // Si arrancó con solo el último canal, al llegar la lista completa se cambia sin interrumpir el video
    LaunchedEffect(channels) {
        if (playlist.size <= 1 && channels.size > 1) {
            val u = playlist.getOrNull(index)?.url
            val iv = visible.indexOfFirst { it.url == u }
            if (iv >= 0) { playlist = visible; index = iv }
            else {
                val ia = channels.indexOfFirst { it.url == u }
                if (ia >= 0) { playlist = channels; index = ia }
            }
        }
    }

    var mode by remember { mutableStateOf(Mode.NONE) }
    var openGroup by remember { mutableStateOf<String?>(null) } // null = Todos
    var backTo by remember { mutableStateOf(Mode.CATEGORIES) }   // a dónde regresa "Atrás"
    var numberFor by remember { mutableStateOf<String?>(null) }  // categoría a la que le pones número
    var stoppedByLeave by remember { mutableStateOf(false) }
    var resumeTick by remember { mutableIntStateOf(0) }
    var overlay by remember { mutableStateOf(true) }
    var okMode by remember { mutableStateOf(false) } // la barra se abrió con OK
    var size by remember { mutableStateOf(VideoSize.UNKNOWN) }
    var failures by remember { mutableIntStateOf(0) }
    var buffering by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    val rootFocus = remember { FocusRequester() }

    fun step(d: Int) {
        if (playlist.isEmpty()) return
        index = (index + d + playlist.size) % playlist.size
    }
    fun pick(list: List<Channel>, i: Int) {
        playlist = list
        index = i
        mode = Mode.NONE
        pip = false
    }
    fun openPanel(m: Mode, back: Mode) {
        backTo = back
        mode = m
    }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) { size = videoSize }
            override fun onPlayerError(error: PlaybackException) { lastError = error.errorCodeName; failures += 1 }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) { failures = 0; status = null }
                if (state == Player.STATE_ENDED && isVodNow) {
                    val c = playlist.getOrNull(index)
                    val d = player.duration
                    if (c != null && d != C.TIME_UNSET) saveResume(prefs, c.url, d, d)
                    // Siguiente episodio / película de la lista
                    if (index < playlist.size - 1) step(1)
                }
            }
            override fun onTracksChanged(tracks: Tracks) {
                hasText = tracks.groups.any { it.type == C.TRACK_TYPE_TEXT }
                vodTick++
            }
            override fun onRenderedFirstFrame() {
                if (zapStart > 0L) {
                    val ms = android.os.SystemClock.elapsedRealtime() - zapStart
                    zapStart = 0L
                    zapLast = ms
                    zapSum += ms
                    zapN += 1
                    if (ms > zapWorst) { zapWorst = ms; zapWorstName = nameHolder[0] }
                }
            }
        }
        player.addListener(l)
        // Si este reproductor ya venía precargado, toma su estado actual
        if (player.videoSize.height > 0) size = player.videoSize
        hasText = player.currentTracks.groups.any { it.type == C.TRACK_TYPE_TEXT }
        buffering = player.playbackState == Player.STATE_BUFFERING
        onDispose { player.removeListener(l) }
    }
    DisposableEffect(pool) {
        onDispose { pool.forEach { it.release() } }
    }
    // Subtítulos: se prenden/apagan en todos los reproductores (los precargados también)
    LaunchedEffect(subsOn, pool) {
        pool.forEach { p ->
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subsOn)
                .setPreferredTextLanguage("es")
                .setSelectUndeterminedTextLanguage(true)
                .build()
        }
    }

    // Al presionar Home (o abrir otra pantalla) se detiene el video y el audio
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, pool) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) {
                stoppedByLeave = true
                pool.forEach { it.stop() }
                slotUrl.fill(null)
            } else if (event == Lifecycle.Event.ON_RESUME && stoppedByLeave) {
                stoppedByLeave = false
                resumeTick++
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    // Guarda el canal para abrir ahí la próxima vez
    LaunchedEffect(current.url) {
        if (kindOf(current) != Kind.LIVE) return@LaunchedEffect
        prefs.edit()
            .putString("last_url", current.url)
            .putString("last_name", current.name)
            .putString("last_logo", current.logo ?: "")
            .putString("last_group", current.group)
            .apply()
    }

    var started by remember { mutableStateOf(false) }
    fun isWarm(i: Int, url: String): Boolean {
        val p = pool[i]
        return slotUrl[i] == url && p.playerError == null && p.playbackState != Player.STATE_IDLE
    }
    fun loadSlot(i: Int, url: String, play: Boolean, startMs: Long = 0L) {
        val p = pool[i]
        p.setPlaybackSpeed(1f)
        p.setMediaItem(mediaItemFor(url), startMs)
        p.prepare()
        p.playWhenReady = play
        slotUrl[i] = url
    }
    LaunchedEffect(current.url, pool, resumeTick, preferTs) {
        zapStart = if (started) android.os.SystemClock.elapsedRealtime() else 0L
        val url = streamUrl(current)
        val warm = pool.indices.firstOrNull { it != active && isWarm(it, url) }
        // Si cambias de canal muy rápido, solo conecta al último (salvo que ya esté precargado)
        if (warm == null && started) delay(60)
        started = true
        // 1) primero la conexión; después lo visual
        if (warm != null) {
            pool[active].playWhenReady = false // el anterior se queda precargado
            pool[warm].playWhenReady = true
            active = warm
        } else {
            // Películas: continúa donde te quedaste
            val rs = if (kindOf(current) != Kind.LIVE) readResume(prefs).firstOrNull { it.url == current.url }?.pos ?: 0L else 0L
            if (rs > 0) Toast.makeText(ctx, "Continuando desde ${fmtTime(rs)}", Toast.LENGTH_SHORT).show()
            loadSlot(active, url, true, rs)
        }
        vodSpeed = 1f
        size = VideoSize.UNKNOWN
        failures = 0
        status = null
        vodPaused = false
        overlay = true
        okMode = false

        // 2) Precarga de vecinos (un poco después, para no competir con el canal principal)
        if (pool.size > 1 && kindOf(current) == Kind.LIVE) {
            delay(500)
            val n = playlist.size
            val wanted = if (n > 1) listOf(playlist[(index + 1) % n], playlist[(index - 1 + n) % n])
                .map { streamUrl(it) }.distinct().filter { it != url } else emptyList()
            val others = pool.indices.filter { it != active }
            val toLoad = wanted.filter { w -> others.none { isWarm(it, w) } }.toMutableList()
            for (i in others) {
                val u = slotUrl[i]
                if (u != null && u in wanted && isWarm(i, u)) continue
                if (toLoad.isNotEmpty()) loadSlot(i, toLoad.removeAt(0), false)
                else { pool[i].stop(); slotUrl[i] = null }
            }
        }
    }
    // Porcentaje de carga del canal (estimado con lo que ya llegó al buffer)
    var loadPct by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(player, current.url, resumeTick) {
        val target = if (preload) 500L else when (bufferLevel) { 0 -> 500L; 2 -> 1500L; else -> 800L }
        loadPct = 0
        while (true) {
            if (player.isPlaying) { loadPct = null; break }
            loadPct = if (player.playbackState == Player.STATE_IDLE) 0
            else (player.totalBufferedDuration * 100 / target).toInt().coerceIn(0, 99)
            delay(100)
        }
    }
    // Guarda el minuto de la película cada 5 s
    LaunchedEffect(isVod, current.url, player) {
        if (!isVod) return@LaunchedEffect
        while (true) {
            delay(5000)
            val d = player.duration
            if (player.isPlaying && d != C.TIME_UNSET && d > 0) saveResume(prefs, current.url, player.currentPosition, d)
        }
    }
    // Mientras ves el catálogo, el video se pausa; al salir se reanuda
    val browsing = (mode == Mode.MOVIES || mode == Mode.SERIES || mode == Mode.EPISODES || mode == Mode.VODSEARCH) && !pip
    LaunchedEffect(isVod) { if (!isVod) pip = false }
    var wasBrowsing by remember { mutableStateOf(false) }
    LaunchedEffect(browsing) {
        if (browsing) { player.pause(); wasBrowsing = true }
        else if (wasBrowsing) {
            wasBrowsing = false
            if (isVod) { if (!vodPaused) player.play() } else resumeTick++
        }
    }
    LaunchedEffect(overlay, current.url, mode, scrubPos) {
        if (overlay && mode == Mode.NONE) {
            delay(overlaySecs * 1000L)
            overlay = false
            okMode = false
        }
    }
    LaunchedEffect(mode, dialogOpen) {
        if (mode == Mode.NONE && !dialogOpen) runCatching { rootFocus.requestFocus() }
    }
    // Reintenta solo si el stream falla (pausas de 1, 2, 4... hasta 8 s)
    LaunchedEffect(failures, player) {
        if (failures == 0) return@LaunchedEffect
        if (failures > 6) { status = "Sin señal"; return@LaunchedEffect }
        status = "Reconectando... ($failures) $lastError"
        delay(minOf(1000L shl (failures - 1), 8000L))
        if (stoppedByLeave) return@LaunchedEffect
        // Si el formato .ts forzado no funciona, vuelve a la URL original
        val u = if (failures >= 3) current.url else streamUrl(current)
        player.setMediaItem(mediaItemFor(u), if (isVod) player.currentPosition else 0L)
        player.prepare()
        player.playWhenReady = true
    }
    // Si se queda cargando más de 15 s, cuenta como falla
    LaunchedEffect(buffering, failures, current.url) {
        if (buffering && failures <= 6) { delay(if (isVod) 45000L else 15000L); failures += 1 }
    }

    fun exitVod() {
        val l = lastLive ?: visibleNow.firstOrNull() ?: return
        val v = visibleNow
        val i = v.indexOfFirst { it.url == l.url }
        playlist = v
        index = if (i >= 0) i else 0
    }
    fun seekBy(ms: Long) {
        val dur = player.duration
        var t = player.currentPosition + ms
        if (dur != C.TIME_UNSET && dur > 0) t = t.coerceAtMost(dur - 1000)
        player.seekTo(t.coerceAtLeast(0))
        overlay = true
    }
    fun togglePause() {
        player.playWhenReady = !player.playWhenReady
        vodPaused = !player.playWhenReady
        overlay = true
        okMode = true
    }
    // Línea de tiempo: avanza de 5 s durante el primer minuto recorrido, luego de 10 s, de 20 s y después de 1 min
    fun scrub(dir: Int) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - scrubState[1] > 1500L) scrubState[0] = 0L // empezó un movimiento nuevo
        scrubState[1] = now
        val speed = prefs.getInt("scrub_speed", 1) // 0 normal, 1 lenta, 2 muy lenta
        val moved = scrubState[0]
        val stepMs = when (speed) {
            0 -> when { moved < 60_000L -> 5_000L; moved < 120_000L -> 10_000L; moved < 180_000L -> 20_000L; else -> 60_000L }
            1 -> when { moved < 30_000L -> 3_000L; moved < 90_000L -> 5_000L; moved < 180_000L -> 10_000L; moved < 360_000L -> 30_000L; else -> 60_000L }
            else -> when { moved < 20_000L -> 2_000L; moved < 60_000L -> 3_000L; moved < 150_000L -> 5_000L; moved < 300_000L -> 15_000L; else -> 30_000L }
        }
        val dur = player.duration
        var t = (scrubPos ?: player.currentPosition) + dir * stepMs
        if (dur != C.TIME_UNSET && dur > 0) t = t.coerceAtMost(dur - 1000)
        scrubPos = t.coerceAtLeast(0L)
        scrubState[0] += stepMs
        overlay = true
    }
    fun commitScrub() {
        scrubPos?.let { player.seekTo(it) }
        scrubPos = null
    }
    // Cuando dejas de mover la línea de tiempo (0.7 s) salta a ese punto
    LaunchedEffect(scrubPos) {
        if (scrubPos == null) return@LaunchedEffect
        delay(700)
        commitScrub()
    }

    val dialogOpenNow by rememberUpdatedState(dialogOpen)
    val curKind by rememberUpdatedState(kindOf(current))
    // Atrás:
    //  - viendo una película: se hace miniatura (arriba a la derecha) y sale el catálogo
    //  - con la miniatura: vuelve a pantalla completa
    //  - en cualquier otro caso: limpia la pantalla
    fun handleBack(): Boolean {
        val catalog = mode == Mode.MOVIES || mode == Mode.SERIES
        val catalogMode = if (curKind == Kind.SERIES) Mode.SERIES else Mode.MOVIES
        return when {
            dialogOpenNow || numberFor != null -> false
            isVodNow && pip && catalog -> { pip = false; mode = Mode.NONE; overlay = false; okMode = false; true }
            isVodNow && pip && (mode == Mode.VODSEARCH || mode == Mode.EPISODES) -> { mode = catalogMode; true }
            mode == Mode.VODTRACKS -> { mode = Mode.VODOPTS; true }
            isVodNow && mode == Mode.NONE -> { pip = true; mode = catalogMode; overlay = false; okMode = false; true }
            mode != Mode.NONE || overlay -> { mode = Mode.NONE; overlay = false; okMode = false; pip = false; true }
            else -> false
        }
    }
    DisposableEffect(ctx) {
        val act = ctx as? MainActivity
        var consumedDown = false
        act?.backInterceptor = { down ->
            if (down) {
                val h = handleBack()
                if (h) consumedDown = true
                h
            } else {
                val c = consumedDown
                consumedDown = false
                c
            }
        }
        onDispose { act?.backInterceptor = null }
    }

    BackHandler(enabled = mode != Mode.NONE || overlay || isVod) { handleBack() }

    val showInfo = overlay && (mode == Mode.NONE || mode == Mode.QUICK)

    val curGroup by rememberUpdatedState(current.group)
    val compactUi = LocalConfiguration.current.screenWidthDp < 700
    val pipW = if (compactUi) 220.dp else 320.dp
    val pipH = if (compactUi) 124.dp else 180.dp
    Box(
        Modifier
            .fillMaxSize()
            // Pantalla táctil: toque = OK, doble toque = barra rápida, deslizar arriba/abajo = cambiar canal,
            // deslizar a la derecha = carpeta del canal, deslizar a la izquierda = ajustes
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        if (mode != Mode.NONE) mode = Mode.NONE
                        else if (overlay && okMode) { overlay = false; okMode = false }
                        else { overlay = true; okMode = true }
                    },
                    onDoubleTap = {
                        if (mode == Mode.NONE) { overlay = true; okMode = true; mode = Mode.QUICK }
                    }
                )
            }
            .pointerInput(Unit) {
                var dx = 0f
                var dy = 0f
                detectDragGestures(
                    onDragStart = { dx = 0f; dy = 0f },
                    onDrag = { _, d -> dx += d.x; dy += d.y },
                    onDragEnd = {
                        if (mode == Mode.NONE && !isVodNow) {
                            if (abs(dy) > abs(dx) && abs(dy) > 140f) step(if (dy < 0) 1 else -1)
                            else if (abs(dx) > 200f) {
                                if (dx > 0) { openGroup = curGroup; openPanel(Mode.CHANNELS, Mode.NONE) }
                                else openPanel(Mode.SETTINGS, Mode.NONE)
                            }
                        }
                    }
                )
            }
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown || mode != Mode.NONE) return@onPreviewKeyEvent false
                when (e.key) {
                    Key.DirectionLeft -> {
                        if (isVod) scrub(-1)
                        else {
                            openGroup = current.group
                            openPanel(Mode.CHANNELS, Mode.NONE)
                        }
                        true
                    }
                    Key.DirectionRight -> {
                        if (isVod) scrub(1) else openPanel(Mode.SETTINGS, Mode.NONE)
                        true
                    }
                    Key.DirectionCenter, Key.Enter -> {
                        if (isVod) { if (scrubPos != null) commitScrub() else togglePause() }
                        else if (overlay && okMode) { overlay = false; okMode = false }
                        else { overlay = true; okMode = true }
                        true
                    }
                    Key.MediaPlayPause, Key.MediaPlay, Key.MediaPause ->
                        if (isVod) { togglePause(); true } else false
                    Key.Menu -> { openPanel(Mode.CATEGORIES, Mode.NONE); true }
                    Key.ChannelUp -> { step(1); true }
                    Key.DirectionUp -> {
                        // En película, Arriba abre el catálogo
                        if (isVod) { pip = true; openPanel(if (kindOf(current) == Kind.SERIES) Mode.SERIES else Mode.MOVIES, Mode.NONE) } else step(-1)
                        true
                    }
                    Key.ChannelDown -> { step(-1); true }
                    Key.DirectionDown -> {
                        // OK y luego abajo: abre la barra con la lupa y la estrella (en película: opciones)
                        if (isVod) mode = Mode.VODOPTS
                        else if (overlay && okMode) mode = Mode.QUICK else step(1)
                        true
                    }
                    else -> false
                }
            }
            .focusRequester(rootFocus)
            .focusable()
    ) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    useController = false
                    isFocusable = false
                    isFocusableInTouchMode = false
                    setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                }
            },
            update = {
                // Al cambiar de canal deja la última imagen en pantalla (en vez de negro) hasta que llegue la nueva
                it.setKeepContentOnPlayerReset(keepFrame)
                it.resizeMode = when (aspect) {
                    1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
                it.player = player
            },
            modifier = if (pip) Modifier.align(Alignment.TopEnd).padding(24.dp).size(pipW, pipH).zIndex(1f)
            else Modifier.fillMaxSize()
        )
        if (pip) {
            Box(Modifier.align(Alignment.TopEnd).padding(24.dp).size(pipW, pipH).zIndex(2f).border(2.dp, Color.White))
            Pill(
                current.name,
                Modifier.align(Alignment.TopEnd).padding(top = 24.dp + pipH + 6.dp, end = 24.dp).zIndex(2f),
                14.sp
            )
        }

        AnimatedVisibility(
            visible = showInfo,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopEnd).padding(24.dp)
        ) { Clock() }

        AnimatedVisibility(
            visible = showInfo && !isVod,
            enter = fadeIn() + slideInVertically { it / 2 },
            exit = fadeOut() + slideOutVertically { it / 2 },
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            val res = if (size.height > 0) "${size.width}x${size.height}" else ""
            PlayerOverlay(current, res, current.url in favs)
        }

        AnimatedVisibility(
            visible = isVod && ((showInfo && mode == Mode.NONE) || mode == Mode.VODOPTS),
            enter = fadeIn() + slideInVertically { it / 2 },
            exit = fadeOut() + slideOutVertically { it / 2 },
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            VodControls(
                player = player, title = current.name, paused = vodPaused, scrubPos = scrubPos,
                interactive = mode == Mode.VODOPTS, barFocus = barFocus,
                onScrub = { scrub(it) },
                onOk = { if (scrubPos != null) commitScrub() else togglePause() },
                speedLabel = "${vodSpeed}x",
                aspectLabel = listOf("Normal", "Llenar", "Estirar")[aspect.coerceIn(0, 2)],
                isFav = current.url in favs,
                onAudio = { trackKind = 0; mode = Mode.VODTRACKS },
                onSubs = { trackKind = 1; mode = Mode.VODTRACKS },
                onSpeed = {
                    val opts = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)
                    vodSpeed = opts[(opts.indexOf(vodSpeed).coerceAtLeast(0) + 1) % opts.size]
                    player.setPlaybackSpeed(vodSpeed)
                },
                onAspect = {
                    aspect = (aspect + 1) % 3
                    prefs.edit().putInt("aspect", aspect).apply()
                },
                onFav = { toggleFav(current) }
            )
        }
        if (isVod && vodPaused && mode == Mode.NONE) Pill("Pausa", Modifier.align(Alignment.Center), 26.sp)

        // Flecha en V que invita a presionar "abajo" para abrir la barra rápida
        AnimatedVisibility(
            visible = showInfo && okMode && mode == Mode.NONE && !isVod,
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 190.dp)
        ) { DownHint() }

        AnimatedVisibility(
            visible = mode == Mode.QUICK,
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it },
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 200.dp)
        ) {
            QuickBar(
                isFav = current.url in favs,
                onSearch = { openPanel(if (isVod) Mode.VODSEARCH else Mode.SEARCH, Mode.NONE) },
                onFavorites = { openPanel(Mode.FAVORITES, Mode.NONE) },
                onToggleFav = { toggleFav(current) },
                subsOn = subsOn,
                hasText = hasText,
                aspectLabel = listOf("Normal", "Llenar", "Estirar")[aspect.coerceIn(0, 2)],
                aspectGlyph = listOf("FIT", "ZOOM", "FULL")[aspect.coerceIn(0, 2)],
                onSubs = {
                    if (!hasText) {
                        Toast.makeText(ctx, "Este canal no trae subtítulos", Toast.LENGTH_SHORT).show()
                    } else {
                        subsOn = !subsOn
                        prefs.edit().putBoolean("subs", subsOn).apply()
                    }
                },
                onAspect = {
                    aspect = (aspect + 1) % 3
                    prefs.edit().putInt("aspect", aspect).apply()
                }
            )
        }

        if (channels.size <= 1) Pill("Cargando lista de canales...", Modifier.align(Alignment.TopStart).padding(24.dp), 18.sp)
        status?.let { Pill(it, Modifier.align(Alignment.Center), 26.sp) }
        if (status == null) loadPct?.let { Pill("Cargando canal... $it%", Modifier.align(Alignment.Center), 26.sp) }

        val side = Modifier.align(Alignment.CenterStart)
        when (mode) {
            Mode.NONE, Mode.QUICK -> {}
            Mode.CATEGORIES -> CategoriesPanel(
                modifier = side,
                groups = order.filter { it !in hidden }.map { it to (counts[it] ?: 0) },
                total = visible.size,
                favCount = favList.size,
                selected = openGroup,
                visible = visible,
                favList = favList,
                byGroup = byGroup,
                current = current,
                favs = favs,
                onToggleFav = { toggleFav(it) },
                onPick = { l, i -> pick(l, i) },
                onSearch = { openPanel(Mode.SEARCH, Mode.CATEGORIES) },
                onManage = { openPanel(Mode.MANAGE, Mode.CATEGORIES) },
                onSettings = { openPanel(Mode.SETTINGS, Mode.CATEGORIES) },
                movieCount = movies.size,
                seriesCount = shows.size,
                onMovies = { openPanel(Mode.MOVIES, Mode.NONE) },
                onSeries = { openPanel(Mode.SERIES, Mode.NONE) }
            )
            Mode.CHANNELS -> {
                val g = openGroup
                val list = remember(g, channels, visible) {
                    if (g == null) visible else channels.filter { it.group == g }
                }
                ChannelsPanel(
                    modifier = side, title = g ?: "Todos", list = list, current = current,
                    favs = favs, onToggleFav = { toggleFav(it) }, emptyText = null,
                    onLeft = { openPanel(Mode.CATEGORIES, Mode.NONE) }
                ) { l, i -> pick(l, i) }
            }
            Mode.FAVORITES -> ChannelsPanel(
                modifier = side, title = "★  Favoritos", list = favList, current = current,
                favs = favs, onToggleFav = { toggleFav(it) },
                emptyText = "Aún no tienes favoritos.\nEn la barra de abajo elige «Agregar a ★»,\no mantén presionado OK sobre un canal.",
                onLeft = { openPanel(Mode.CATEGORIES, Mode.NONE) }
            ) { l, i -> pick(l, i) }
            Mode.SEARCH -> SearchPanel(
                modifier = side, index = searchIndex, hidden = hidden,
                favs = favs, onToggleFav = { toggleFav(it) }
            ) { l, i -> pick(l, i) }
            Mode.MANAGE -> ManagePanel(
                modifier = side,
                order = order,
                hidden = hidden,
                counts = counts,
                dialogOpen = numberFor != null,
                onMove = { i, d -> order = moveItem(order, i, d); save() },
                onToggle = { g ->
                    hidden = if (g in hidden) hidden - g else hidden + g
                    save()
                },
                onAskNumber = { numberFor = it }
            )
            Mode.SETTINGS -> SettingsPanel(
                modifier = side,
                version = Updater.currentVersion(ctx),
                listName = lists.firstOrNull { it.second == (prefs.getString("m3u", "") ?: "") }?.first ?: "—",
                bufferLevel = bufferLevel,
                overlaySecs = overlaySecs,
                scrubSpeed = scrubSpeed,
                onScrubSpeed = {
                    scrubSpeed = (scrubSpeed + 1) % 3
                    prefs.edit().putInt("scrub_speed", scrubSpeed).apply()
                },
                onTheme = {
                    Th.themeIdx = (Th.themeIdx + 1) % themeDefs.size
                    prefs.edit().putInt("theme", Th.themeIdx).apply()
                },
                onAccent = {
                    Th.accentIdx = (Th.accentIdx + 1) % accentDefs.size
                    prefs.edit().putInt("accent", Th.accentIdx).apply()
                },
                autoUpdate = autoUpdate,
                preload = preload,
                preferTs = preferTs,
                keepFrame = keepFrame,
                logoDiag = "${allChannels.count { it.logo.isNullOrBlank() }} de ${allChannels.size} canales no traen logo en la lista" +
                    (if (LogoDiag.fails > 0) " · ${LogoDiag.fails} descargas fallidas, último: ${LogoDiag.last}" else " · sin descargas fallidas"),
                zapText = if (zapN == 0) "Sin datos aún" else
                    "último ${"%.1f".format(zapLast / 1000.0)} s · prom ${"%.1f".format(zapSum / zapN / 1000.0)} s · peor ${"%.1f".format(zapWorst / 1000.0)} s ($zapWorstName)",
                updateMsg = updateMsg,
                onPreload = {
                    preload = !preload
                    prefs.edit().putBoolean("preload", preload).apply()
                },
                onKeepFrame = {
                    keepFrame = !keepFrame
                    prefs.edit().putBoolean("keep_frame", keepFrame).apply()
                },
                onPreferTs = {
                    preferTs = !preferTs
                    prefs.edit().putBoolean("prefer_ts", preferTs).apply()
                },
                onResetZap = { zapLast = 0; zapSum = 0; zapN = 0; zapWorst = 0; zapWorstName = "" },
                onBuffer = {
                    bufferLevel = (bufferLevel + 1) % 3
                    prefs.edit().putInt("buffer", bufferLevel).apply()
                },
                onOverlay = {
                    val opts = listOf(3, 5, 8, 12)
                    overlaySecs = opts[(opts.indexOf(overlaySecs).coerceAtLeast(0) + 1) % opts.size]
                    prefs.edit().putInt("overlay_s", overlaySecs).apply()
                },
                onAutoUpdate = {
                    autoUpdate = !autoUpdate
                    prefs.edit().putBoolean("auto_update", autoUpdate).apply()
                },
                onCheckUpdate = onCheckUpdate,
                onReload = onReload,
                onLists = { openPanel(Mode.LISTS, Mode.SETTINGS) }
            )
            Mode.MOVIES -> {
                val resumeRow = remember { readResume(prefs).mapNotNull { byUrl.value[it.url] }.filter { kindOf(it) == Kind.MOVIE } }
                val favRow = remember(favs, movies) { movies.filter { it.url in favs } }
                val rows = remember(movies, resumeRow, favRow) {
                    val out = ArrayList<Pair<String, List<PosterItem>>>()
                    if (resumeRow.isNotEmpty()) out.add("Continuar viendo" to resumeRow.map { PosterItem(it.name, it.logo, it) })
                    if (favRow.isNotEmpty()) out.add("★  Favoritos" to favRow.map { PosterItem(it.name, it.logo, it) })
                    movies.groupBy { it.group }.forEach { (g, l) -> out.add(g to l.map { PosterItem(it.name, it.logo, it) }) }
                    out
                }
                PosterBrowser(
                    title = "Películas", rows = rows, pip = pip, pipH = pipH,
                    movieCount = movies.size, seriesCount = shows.size,
                    onTv = { if (isVod) exitVod(); pip = false; openPanel(Mode.CATEGORIES, Mode.NONE) },
                    onMovies = { openPanel(Mode.MOVIES, Mode.NONE) },
                    onSeries = { openPanel(Mode.SERIES, Mode.NONE) },
                    onSearch = { openPanel(Mode.VODSEARCH, Mode.NONE) }
                ) { r, i ->
                    val list = rows[r].second.map { it.payload as Channel }
                    pick(list, i)
                }
            }
            Mode.SERIES -> {
                val resumeRow = remember { readResume(prefs).mapNotNull { epToShow.value[it.url] }.distinct() }
                val rows = remember(shows, resumeRow) {
                    val out = ArrayList<Pair<String, List<PosterItem>>>()
                    if (resumeRow.isNotEmpty()) out.add("Continuar viendo" to resumeRow.map { PosterItem(it.title, it.logo, it) })
                    shows.groupBy { it.group }.forEach { (g, l) -> out.add(g to l.map { PosterItem(it.title, it.logo, it) }) }
                    out
                }
                PosterBrowser(
                    title = "Series", rows = rows, pip = pip, pipH = pipH,
                    movieCount = movies.size, seriesCount = shows.size,
                    onTv = { if (isVod) exitVod(); pip = false; openPanel(Mode.CATEGORIES, Mode.NONE) },
                    onMovies = { openPanel(Mode.MOVIES, Mode.NONE) },
                    onSeries = { openPanel(Mode.SERIES, Mode.NONE) },
                    onSearch = { openPanel(Mode.VODSEARCH, Mode.NONE) }
                ) { r, i ->
                    val sh = rows[r].second[i].payload as Show
                    if (sh.episodes.size == 1) pick(sh.episodes, 0)
                    else { openShow = sh; openPanel(Mode.EPISODES, Mode.NONE) }
                }
            }
            Mode.EPISODES -> {
                val sh = openShow
                if (sh != null) EpisodesPanel(
                    modifier = side, show = sh, favs = favs, onToggleFav = { toggleFav(it) },
                    onBack = { openPanel(Mode.SERIES, Mode.NONE) }
                ) { l, i -> pick(l, i) }
            }
            Mode.VODSEARCH -> SearchPanel(
                modifier = side, index = vodIndex, hidden = emptySet(),
                favs = favs, onToggleFav = { toggleFav(it) }
            ) { l, i -> pick(l, i) }
            Mode.VODOPTS -> {}
            Mode.VODTRACKS -> VodTracksPanel(
                modifier = Modifier.align(Alignment.CenterEnd),
                player = player, tick = vodTick, kind = trackKind,
                onAudio = { g, i ->
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
                    vodTick++
                },
                onSubOff = {
                    subsOn = false
                    prefs.edit().putBoolean("subs", false).apply()
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                    vodTick++
                },
                onSub = { g, i ->
                    subsOn = true
                    prefs.edit().putBoolean("subs", true).apply()
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
                    vodTick++
                }
            )
            Mode.LISTS -> ListsPanel(
                modifier = side,
                lists = lists,
                activeUrl = prefs.getString("m3u", "") ?: "",
                onSelect = { u -> if (u != (prefs.getString("m3u", "") ?: "")) onChangeUrl(u) else mode = Mode.NONE },
                onDelete = { i ->
                    val gone = lists.getOrNull(i)
                    if (gone != null) {
                        val rest = lists.filterIndexed { j, _ -> j != i }
                        lists = rest
                        saveLists(prefs, rest)
                        runCatching { cacheFileFor(ctx, gone.second).let { it.delete(); binFor(it).delete() } }
                        if (gone.second == (prefs.getString("m3u", "") ?: "")) {
                            // Borraste la lista que estabas usando: pasa a otra, o pide una nueva
                            onChangeUrl(rest.firstOrNull()?.second ?: "")
                        }
                    }
                },
                onAdd = { name, link -> onNewList(name, link) }
            )
        }

        numberFor?.let { g ->
            NumberDialog(g, order.indexOf(g) + 1, order.size, onCancel = { numberFor = null }) { n ->
                order = moveTo(order, g, n - 1)
                save()
                numberFor = null
            }
        }
    }
}

// ---------------- Barra rápida (OK + abajo) ----------------

@Composable
private fun DownHint(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "hint")
    val dy by t.animateFloat(
        initialValue = 0f, targetValue = 12f,
        animationSpec = infiniteRepeatable(tween(650, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "dy"
    )
    val a by t.animateFloat(
        initialValue = 0.45f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
        label = "a"
    )
    Canvas(
        modifier
            .size(width = 72.dp, height = 30.dp)
            .graphicsLayer { translationY = dy; alpha = a }
    ) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.10f, h * 0.10f)
            lineTo(w * 0.50f, h * 0.88f)
            lineTo(w * 0.90f, h * 0.10f)
        }
        // sombra oscura debajo para que se vea sobre cualquier imagen
        drawPath(path, Color(0x99000000), style = Stroke(width = 13.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(path, Color.White, style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
private fun QuickBar(
    isFav: Boolean,
    onSearch: () -> Unit,
    onFavorites: () -> Unit,
    onToggleFav: () -> Unit,
    subsOn: Boolean,
    hasText: Boolean,
    aspectLabel: String,
    aspectGlyph: String,
    onSubs: () -> Unit,
    onAspect: () -> Unit
) {
    val compact = LocalConfiguration.current.screenWidthDp < 700
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    val shape = RoundedCornerShape(48.dp)
    Row(
        Modifier
            .clip(shape)
            .background(Th.theme.card.copy(alpha = 0.93f))
            .border(1.dp, Color(0x33FFFFFF), shape)
            .padding(horizontal = if (compact) 24.dp else 44.dp, vertical = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(if (compact) 18.dp else 36.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        QuickButton(Icons.Default.Search, "Buscar", Modifier.focusRequester(focus), onClick = onSearch)
        QuickButton(Icons.Default.Star, "Favoritos", tint = Gold, onClick = onFavorites)
        QuickButton(
            if (isFav) Icons.Default.Check else Icons.Default.Add,
            if (isFav) "Quitar de ★" else "Agregar a ★",
            tint = if (isFav) Gold else Color.White,
            onClick = onToggleFav
        )
        QuickButton(
            null, "Subtítulos", glyph = "CC",
            tint = if (subsOn && hasText) Gold else if (hasText) Color.White else Color(0xFF777777),
            onClick = onSubs
        )
        QuickButton(null, "Pantalla: $aspectLabel", glyph = aspectGlyph, onClick = onAspect)
    }
}

@Composable
private fun QuickButton(
    icon: ImageVector?,
    label: String,
    modifier: Modifier = Modifier,
    glyph: String? = null,
    tint: Color = Color.White,
    draw: (DrawScope.(Color) -> Unit)? = null,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.15f else 1f)
    val bg: Brush = if (focused) AccentBrush else SolidColor(Color(0x26FFFFFF))
    Column(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(78.dp).clip(CircleShape).background(bg),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(40.dp))
            else if (draw != null) Canvas(Modifier.size(42.dp)) { draw(tint) }
            else if (glyph != null) Text(glyph, fontSize = if (glyph.length > 2) 18.sp else 26.sp, fontWeight = FontWeight.Bold, color = tint)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 18.sp, color = if (focused) Color.White else Gray)
    }
}

// ---------------- Paneles ----------------

@Composable
private fun SidePanel(modifier: Modifier, width: Dp, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxHeight()
            .fillMaxWidth()
            .widthIn(max = width)
            .background(
                Brush.horizontalGradient(
                    listOf(bg(0.98f), bg(0.9f), Color.Transparent)
                )
            )
            .padding(start = 16.dp, end = 48.dp, top = 24.dp, bottom = 16.dp),
        content = content
    )
}

@Composable
private fun PanelTitle(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp, bottom = 10.dp)) {
        AppLogo(40.dp)
        Spacer(Modifier.width(12.dp))
        Text(text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CategoriesPanel(
    modifier: Modifier,
    groups: List<Pair<String, Int>>,
    total: Int,
    favCount: Int,
    selected: String?,
    visible: List<Channel>,
    favList: List<Channel>,
    byGroup: Map<String, List<Channel>>,
    current: Channel,
    favs: Set<String>,
    onToggleFav: (Channel) -> Unit,
    onPick: (List<Channel>, Int) -> Unit,
    onSearch: () -> Unit,
    onManage: () -> Unit,
    onSettings: () -> Unit,
    movieCount: Int,
    seriesCount: Int,
    onMovies: () -> Unit,
    onSeries: () -> Unit
) {
    // Qué carpeta se está "viendo": al moverte por la lista, a su lado salen sus canales
    var preview by remember { mutableStateOf(selected ?: CAT_ALL) }
    val compactScreen = LocalConfiguration.current.screenWidthDp < 700
    var showTools by remember { mutableStateOf(compactScreen) }
    var showSections by remember { mutableStateOf(false) }
    val secFocus = remember { FocusRequester() }
    LaunchedEffect(showSections) {
        if (showSections) {
            repeat(4) {
                if (runCatching { secFocus.requestFocus() }.isSuccess) return@LaunchedEffect
                delay(60)
            }
        }
    }
    val catFocus = remember { FocusRequester() }
    val chanFocus = remember { FocusRequester() }
    val toolFocus = remember { FocusRequester() }
    val selIdx = when (preview) {
        CAT_ALL -> 0
        CAT_FAV -> 1
        else -> groups.indexOfFirst { it.first == preview } + 2
    }
    val state = rememberLazyListState(initialFirstVisibleItemIndex = selIdx.coerceAtLeast(0))
    LaunchedEffect(Unit) { runCatching { catFocus.requestFocus() } }
    LaunchedEffect(showTools) {
        if (showTools) {
            repeat(4) {
                if (runCatching { toolFocus.requestFocus() }.isSuccess) return@LaunchedEffect
                delay(60)
            }
        }
    }

    val list = when (preview) {
        CAT_ALL -> visible
        CAT_FAV -> favList
        else -> byGroup[preview] ?: emptyList()
    }
    val goRight = { runCatching { chanFocus.requestFocus() }; Unit }
    val goLeft = { showTools = true }

    Row(
        modifier
            .fillMaxHeight()
            .fillMaxWidth(if (LocalConfiguration.current.screenWidthDp < 700) 0.94f else 0.70f)
            .background(
                Brush.horizontalGradient(
                    colorStops = arrayOf(
                        0f to bg(0.98f),
                        0.80f to bg(0.92f),
                        1f to Color.Transparent
                    )
                )
            )
            .padding(start = 16.dp, end = 24.dp, top = 20.dp, bottom = 16.dp)
    ) {
        // ---- Secciones (otra izquierda más): TV, películas, series ----
        AnimatedVisibility(
            visible = showSections,
            enter = fadeIn() + expandHorizontally(),
            exit = fadeOut() + shrinkHorizontally()
        ) {
            Column(
                Modifier
                    .fillMaxHeight()
                    .padding(end = 20.dp)
                    .onPreviewKeyEvent { e ->
                        if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                        when (e.key) {
                            Key.DirectionRight -> {
                                showSections = false
                                showTools = false
                                runCatching { catFocus.requestFocus() }
                                true
                            }
                            Key.DirectionLeft -> true
                            else -> false
                        }
                    },
                verticalArrangement = Arrangement.spacedBy(32.dp, Alignment.CenterVertically),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                QuickButton(null, "TV", Modifier.focusRequester(secFocus), draw = { c -> drawTv(c) }) {
                    showSections = false
                    showTools = false
                    runCatching { catFocus.requestFocus() }
                }
                if (movieCount > 0) QuickButton(null, "Películas", draw = { c -> drawFilm(c) }, onClick = onMovies)
                if (seriesCount > 0) QuickButton(null, "Series", draw = { c -> drawSeries(c) }, onClick = onSeries)
            }
        }

        // ---- Herramientas (aparecen al darle izquierda otra vez): lupa, lápiz, tuerca ----
        AnimatedVisibility(
            visible = showTools,
            enter = fadeIn() + expandHorizontally(),
            exit = fadeOut() + shrinkHorizontally()
        ) {
            Column(
                Modifier
                    .fillMaxHeight()
                    .padding(end = 20.dp)
                    .onPreviewKeyEvent { e ->
                        if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                        when (e.key) {
                            Key.DirectionRight -> {
                                runCatching { catFocus.requestFocus() }
                                showTools = false
                                true
                            }
                            Key.DirectionLeft -> { if (movieCount + seriesCount > 0) showSections = true; true }
                            else -> false
                        }
                    },
                verticalArrangement = Arrangement.spacedBy(32.dp, Alignment.CenterVertically),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                QuickButton(Icons.Default.Search, "Buscar", Modifier.focusRequester(toolFocus), onClick = onSearch)
                QuickButton(Icons.Default.Edit, "Editar", onClick = onManage)
                QuickButton(Icons.Default.Settings, "Ajustes", onClick = onSettings)
            }
        }

        // ---- Carpetas (ocupan toda la altura) ----
        Column(Modifier.weight(0.42f).fillMaxHeight()) {
            LazyColumn(state = state) {
                item {
                    CategoryRow(
                        "Todos", total, preview == CAT_ALL,
                        if (preview == CAT_ALL) Modifier.focusRequester(catFocus) else Modifier,
                        onFocusIn = { preview = CAT_ALL }, onRight = goRight, onLeft = goLeft, onClick = goRight
                    )
                }
                item {
                    CategoryRow(
                        "★  Favoritos", favCount, preview == CAT_FAV,
                        if (preview == CAT_FAV) Modifier.focusRequester(catFocus) else Modifier,
                        onFocusIn = { preview = CAT_FAV }, onRight = goRight, onLeft = goLeft, onClick = goRight
                    )
                }
                itemsIndexed(groups, key = { _, g -> g.first }) { _, g ->
                    CategoryRow(
                        g.first, g.second, preview == g.first,
                        if (preview == g.first) Modifier.focusRequester(catFocus) else Modifier,
                        onFocusIn = { preview = g.first }, onRight = goRight, onLeft = goLeft, onClick = goRight
                    )
                }
            }
        }

        Spacer(Modifier.width(16.dp))
        Box(Modifier.width(1.dp).fillMaxHeight().background(Color(0x22FFFFFF)))
        Spacer(Modifier.width(16.dp))

        // ---- Canales de la carpeta que tienes seleccionada ----
        key(preview) {
            val start = list.indexOfFirst { it.url == current.url }.coerceAtLeast(0)
            val cState = rememberLazyListState(initialFirstVisibleItemIndex = start)
            Column(
                Modifier
                    .weight(0.58f)
                    .fillMaxHeight()
                    .onPreviewKeyEvent { e ->
                        if (e.type == KeyEventType.KeyDown && e.key == Key.DirectionLeft) {
                            runCatching { catFocus.requestFocus() }
                            true
                        } else false
                    }
            ) {
                Text(
                    when (preview) {
                        CAT_ALL -> "Todos"
                        CAT_FAV -> "★  Favoritos"
                        else -> preview
                    },
                    fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                    modifier = Modifier.padding(start = 8.dp, top = 4.dp, bottom = 8.dp)
                )
                if (list.isEmpty()) {
                    Text(
                        if (preview == CAT_FAV) "Aún no tienes favoritos.\nMantén presionado OK sobre un canal para agregarlo."
                        else "No hay canales",
                        fontSize = 20.sp, color = Gray,
                        modifier = Modifier.padding(start = 8.dp, top = 8.dp)
                    )
                } else {
                    LazyColumn(state = cState) {
                        itemsIndexed(list) { i, ch ->
                            ChannelRow(
                                ch, ch.url in favs,
                                if (i == start) Modifier.focusRequester(chanFocus) else Modifier,
                                { onToggleFav(ch) }
                            ) { onPick(list, i) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryRow(
    title: String,
    count: Int,
    selected: Boolean,
    modifier: Modifier,
    onFocusIn: () -> Unit,
    onRight: () -> Unit,
    onLeft: () -> Unit,
    onClick: () -> Unit
) {
    FocusRow(
        modifier.onPreviewKeyEvent { e ->
            if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
            when (e.key) {
                Key.DirectionRight -> { onRight(); true }
                Key.DirectionLeft -> { onLeft(); true }
                else -> false
            }
        },
        onClick,
        onFocusIn = onFocusIn,
        highlight = selected
    ) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(12.dp))
        Box(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(Color(0x26FFFFFF))
                .padding(horizontal = 14.dp, vertical = 2.dp)
        ) { Text("$count", fontSize = 17.sp, color = Color.White) }
    }
}

@Composable
private fun ChannelsPanel(
    modifier: Modifier,
    title: String,
    list: List<Channel>,
    current: Channel,
    favs: Set<String>,
    onToggleFav: (Channel) -> Unit,
    emptyText: String?,
    onLeft: () -> Unit,
    onPick: (List<Channel>, Int) -> Unit
) {
    val focus = remember { FocusRequester() }
    val start = list.indexOfFirst { it.url == current.url }.coerceAtLeast(0)
    val state = rememberLazyListState(initialFirstVisibleItemIndex = start)
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    SidePanel(
        modifier.onPreviewKeyEvent { e ->
            if (e.type == KeyEventType.KeyDown && e.key == Key.DirectionLeft) { onLeft(); true } else false
        },
        600.dp
    ) {
        PanelTitle(title)
        if (list.isEmpty()) {
            Text(
                emptyText ?: "No hay canales",
                fontSize = 20.sp, color = Gray,
                modifier = Modifier.padding(start = 8.dp, top = 8.dp)
            )
        } else {
            Text(
                "Mantén presionado OK para agregar o quitar de favoritos",
                fontSize = 15.sp, color = Gray,
                modifier = Modifier.padding(start = 8.dp, bottom = 6.dp)
            )
            LazyColumn(state = state) {
                itemsIndexed(list) { i, ch ->
                    ChannelRow(
                        ch, ch.url in favs,
                        if (i == start) Modifier.focusRequester(focus) else Modifier,
                        { onToggleFav(ch) }
                    ) { onPick(list, i) }
                }
            }
        }
    }
}

@Composable
private fun SearchPanel(
    modifier: Modifier,
    index: List<Pair<Channel, String>>,
    hidden: Set<String>,
    favs: Set<String>,
    onToggleFav: (Channel) -> Unit,
    onPick: (List<Channel>, Int) -> Unit
) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    val results = remember(q, hidden) {
        val tokens = normalize(q).split(" ").filter { it.isNotBlank() }
        if (tokens.isEmpty()) emptyList()
        else index
            .filter { (c, n) -> c.group !in hidden && tokens.all { n.contains(it) } }
            .map { it.first }
            .take(300)
    }

    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !text.isNullOrBlank()) q = text
    }
    fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Di el nombre del canal")
        }
        try {
            voice.launch(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "Este dispositivo no tiene reconocimiento de voz", Toast.LENGTH_LONG).show()
        }
    }

    SidePanel(modifier, 780.dp) {
        PanelTitle("Buscar canal")
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp)) {
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                singleLine = true,
                label = { Text("Nombre del canal") },
                modifier = Modifier.weight(1f).focusRequester(focus)
            )
            Spacer(Modifier.width(12.dp))
            FocusChip("Voz") { startVoice() }
        }
        Spacer(Modifier.height(12.dp))
        when {
            q.isBlank() -> Text("Escribe o dicta el nombre del canal", color = Gray, modifier = Modifier.padding(start = 8.dp))
            results.isEmpty() -> Text("Sin resultados", color = Gray, modifier = Modifier.padding(start = 8.dp))
            else -> LazyColumn {
                itemsIndexed(results) { i, ch ->
                    ChannelRow(ch, ch.url in favs, Modifier, { onToggleFav(ch) }) { onPick(results, i) }
                }
            }
        }
    }
}

@Composable
private fun ManagePanel(
    modifier: Modifier,
    order: List<String>,
    hidden: Set<String>,
    counts: Map<String, Int>,
    dialogOpen: Boolean,
    onMove: (Int, Int) -> Unit,
    onToggle: (String) -> Unit,
    onAskNumber: (String) -> Unit
) {
    val focus = remember { FocusRequester() }
    val listState = rememberLazyListState()
    val numReqs = remember { mutableMapOf<String, FocusRequester>() }
    var lastNum by remember { mutableStateOf<String?>(null) }
    val orderNow by rememberUpdatedState(order)
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    // Al cerrar el diálogo del número, el foco regresa al botón Nº de esa misma carpeta (ya en su nueva posición)
    LaunchedEffect(dialogOpen) {
        val g = lastNum
        if (!dialogOpen && g != null) {
            lastNum = null
            val idx = orderNow.indexOf(g)
            if (idx >= 0) {
                listState.scrollToItem(idx)
                withFrameNanos { }
                var ok = runCatching { numReqs[g]?.requestFocus() }.isSuccess && numReqs[g] != null
                if (!ok) {
                    delay(100)
                    runCatching { numReqs[g]?.requestFocus() }
                }
            }
        }
    }

    SidePanel(modifier, 880.dp) {
        PanelTitle("Editar categorías")
        Text(
            "▲ ▼ mueve de a una · Nº la manda a la posición que escribas · Ocultar la esconde",
            fontSize = 16.sp, color = Gray, modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
        )
        LazyColumn(state = listState) {
            itemsIndexed(order, key = { _, g -> g }) { i, g ->
                val isHidden = g in hidden
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${i + 1}", fontSize = 22.sp, fontWeight = FontWeight.Bold,
                        color = Gold, modifier = Modifier.width(48.dp)
                    )
                    Column(Modifier.weight(1f)) {
                        Text(
                            g, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                            color = if (isHidden) Color(0xFF777777) else Color.White
                        )
                        Text("${counts[g] ?: 0} canales", fontSize = 16.sp, color = Gray)
                    }
                    FocusChip("▲", if (i == 0) Modifier.focusRequester(focus) else Modifier) { onMove(i, -1) }
                    Spacer(Modifier.width(8.dp))
                    FocusChip("▼") { onMove(i, 1) }
                    Spacer(Modifier.width(8.dp))
                    FocusChip("Nº", Modifier.focusRequester(numReqs.getOrPut(g) { FocusRequester() })) {
                        lastNum = g
                        onAskNumber(g)
                    }
                    Spacer(Modifier.width(8.dp))
                    FocusChip(if (isHidden) "Mostrar" else "Ocultar") { onToggle(g) }
                }
            }
        }
    }
}

@Composable
private fun NumberDialog(
    name: String,
    current: Int,
    total: Int,
    onCancel: () -> Unit,
    onOk: (Int) -> Unit
) {
    var text by remember { mutableStateOf(current.toString()) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    BackHandler { onCancel() }
    fun submit() { text.toIntOrNull()?.let { onOk(it) } }

    Box(
        Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .width(640.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Th.theme.card)
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(24.dp))
                .padding(32.dp)
        ) {
            Text("Posición de la carpeta", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(name, fontSize = 20.sp, color = Gold, maxLines = 1)
            Spacer(Modifier.height(10.dp))
            Text(
                "Escribe un número del 1 al $total. El 1 la manda hasta arriba, el 2 al segundo lugar.",
                fontSize = 18.sp, color = Gray
            )
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { v -> text = v.filter { it.isDigit() }.take(4) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                modifier = Modifier.width(200.dp).focusRequester(focus)
            )
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                FocusChip("Aceptar") { submit() }
                FocusChip("Cancelar") { onCancel() }
            }
        }
    }
}

@Composable
private fun SettingsPanel(
    modifier: Modifier,
    version: String,
    listName: String,
    bufferLevel: Int,
    overlaySecs: Int,
    autoUpdate: Boolean,
    preload: Boolean,
    preferTs: Boolean,
    keepFrame: Boolean,
    zapText: String,
    logoDiag: String,
    updateMsg: String?,
    onPreload: () -> Unit,
    onPreferTs: () -> Unit,
    onKeepFrame: () -> Unit,
    onResetZap: () -> Unit,
    onBuffer: () -> Unit,
    scrubSpeed: Int,
    onScrubSpeed: () -> Unit,
    onTheme: () -> Unit,
    onAccent: () -> Unit,
    onOverlay: () -> Unit,
    onAutoUpdate: () -> Unit,
    onCheckUpdate: () -> Unit,
    onReload: () -> Unit,
    onLists: () -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    val labels = listOf("Bajo", "Normal", "Alto")

    SidePanel(modifier, 780.dp) {
        PanelTitle("Ajustes")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        SettingRow("Tema de la app", Th.theme.name, Modifier.focusRequester(focus), onTheme, swatch = SolidColor(Th.theme.card2))
        SettingRow("Color de la interfaz", accentDefs[Th.accentIdx].first, onClick = onAccent, swatch = AccentBrush)
        SettingRow("Pasos de la línea de tiempo (películas)", listOf("Normal", "Lentos", "Muy lentos")[scrubSpeed.coerceIn(0, 2)], onClick = onScrubSpeed)
        SettingRow("Buffer del video", labels[bufferLevel.coerceIn(0, 2)], onClick = onBuffer)
        SettingRow("Duración de la barra de info", "$overlaySecs s", onClick = onOverlay)
        SettingRow("Precargar canal de arriba y de abajo", if (preload) "Sí (2 conexiones extra)" else "No", onClick = onPreload)
        SettingRow("Dejar la imagen anterior mientras carga", if (keepFrame) "Sí" else "No (pantalla negra)", onClick = onKeepFrame)
        SettingRow("Preferir formato .ts (más rápido)", if (preferTs) "Sí" else "No", onClick = onPreferTs)
        SettingRow("Tiempo de arranque (OK para reiniciar)", zapText, onClick = onResetZap)
        SettingRow("Buscar actualizaciones al abrir", if (autoUpdate) "Sí" else "No", onClick = onAutoUpdate)
        SettingRow("Buscar actualización ahora", updateMsg ?: "Versión $version", onClick = onCheckUpdate)
        SettingRow("Diagnóstico de logos", logoDiag, onClick = {})
        SettingRow("Recargar lista de canales", "", onClick = onReload)
        SettingRow("Mis listas (agregar, cambiar, borrar)", listName, onClick = onLists)
        }
    }
}

private fun DrawScope.drawTv(c: Color) {
    val w = size.width
    val h = size.height
    val sw = 3.dp.toPx()
    drawLine(c, Offset(w * 0.34f, h * 0.04f), Offset(w * 0.5f, h * 0.22f), sw, StrokeCap.Round)
    drawLine(c, Offset(w * 0.66f, h * 0.04f), Offset(w * 0.5f, h * 0.22f), sw, StrokeCap.Round)
    drawRoundRect(
        c, topLeft = Offset(w * 0.06f, h * 0.24f), size = Size(w * 0.88f, h * 0.64f),
        cornerRadius = CornerRadius(7.dp.toPx()), style = Stroke(sw)
    )
    drawLine(c, Offset(w * 0.3f, h * 0.97f), Offset(w * 0.7f, h * 0.97f), sw, StrokeCap.Round)
}

// Rollo de película
private fun DrawScope.drawFilm(c: Color) {
    val w = size.width
    val sw = 3.dp.toPx()
    drawCircle(c, radius = w * 0.44f, center = center, style = Stroke(sw))
    drawCircle(c, radius = w * 0.07f, center = center)
    for (k in 0 until 5) {
        val a = k * 2.0 * Math.PI / 5 - Math.PI / 2
        drawCircle(
            c, radius = w * 0.08f,
            center = Offset(center.x + (w * 0.24f * cos(a)).toFloat(), center.y + (w * 0.24f * sin(a)).toFloat())
        )
    }
}

// Pila de tarjetas (series)
private fun DrawScope.drawSeries(c: Color) {
    val w = size.width
    val h = size.height
    val sw = 3.dp.toPx()
    val r = CornerRadius(5.dp.toPx())
    drawRoundRect(c, Offset(w * 0.22f, h * 0.04f), Size(w * 0.60f, h * 0.30f), r, Stroke(sw), alpha = 0.55f)
    drawRoundRect(c, Offset(w * 0.12f, h * 0.20f), Size(w * 0.76f, h * 0.34f), r, Stroke(sw), alpha = 0.8f)
    drawRoundRect(c, Offset(w * 0.02f, h * 0.38f), Size(w * 0.96f, h * 0.58f), r, Stroke(sw))
    val tri = Path().apply {
        moveTo(w * 0.42f, h * 0.52f)
        lineTo(w * 0.42f, h * 0.82f)
        lineTo(w * 0.66f, h * 0.67f)
        close()
    }
    drawPath(tri, c)
}

@Composable
private fun PlayPauseIcon(paused: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        if (paused) {
            val tri = Path().apply {
                moveTo(w * 0.22f, h * 0.10f)
                lineTo(w * 0.22f, h * 0.90f)
                lineTo(w * 0.88f, h * 0.50f)
                close()
            }
            drawPath(tri, Color.White)
        } else {
            drawRoundRect(Color.White, Offset(w * 0.18f, h * 0.10f), Size(w * 0.24f, h * 0.80f), CornerRadius(3.dp.toPx()))
            drawRoundRect(Color.White, Offset(w * 0.58f, h * 0.10f), Size(w * 0.24f, h * 0.80f), CornerRadius(3.dp.toPx()))
        }
    }
}

@Composable
private fun VodControls(
    player: Player,
    title: String,
    paused: Boolean,
    scrubPos: Long?,
    interactive: Boolean,
    barFocus: FocusRequester,
    onScrub: (Int) -> Unit,
    onOk: () -> Unit,
    speedLabel: String,
    aspectLabel: String,
    isFav: Boolean,
    onAudio: () -> Unit,
    onSubs: () -> Unit,
    onSpeed: () -> Unit,
    onAspect: () -> Unit,
    onFav: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pos by produceState(0L to 0L, player) {
        while (true) {
            val d = player.duration
            value = player.currentPosition to (if (d == C.TIME_UNSET) 0L else d)
            delay(300)
        }
    }
    val shown = scrubPos ?: pos.first
    val frac = if (pos.second > 0) (shown.toFloat() / pos.second).coerceIn(0f, 1f) else 0f
    var barFocused by remember { mutableStateOf(false) }
    LaunchedEffect(interactive) {
        if (interactive) {
            delay(120)
            runCatching { barFocus.requestFocus() }
        }
    }
    Column(
        modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, bg(0.95f))))
            .padding(horizontal = 48.dp, vertical = 28.dp)
    ) {
        Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            PlayPauseIcon(paused, Modifier.size(34.dp))
            Spacer(Modifier.width(16.dp))
            Text(fmtTime(shown), fontSize = 20.sp, color = if (scrubPos != null) Gold else Color.White)
            Spacer(Modifier.width(14.dp))
            Box(
                Modifier
                    .weight(1f)
                    .height(if (barFocused) 16.dp else 10.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0x33FFFFFF))
                    .then(
                        if (interactive) Modifier
                            .focusRequester(barFocus)
                            .onFocusChanged { barFocused = it.isFocused }
                            .onPreviewKeyEvent { e ->
                                if (e.type != KeyEventType.KeyDown) false
                                else when (e.key) {
                                    Key.DirectionLeft -> { onScrub(-1); true }
                                    Key.DirectionRight -> { onScrub(1); true }
                                    Key.DirectionCenter, Key.Enter -> { onOk(); true }
                                    else -> false
                                }
                            }
                            .focusable()
                        else Modifier
                    )
            ) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(AccentBrush))
            }
            Spacer(Modifier.width(14.dp))
            Text("-" + fmtTime((pos.second - shown).coerceAtLeast(0)), fontSize = 20.sp)
        }
        Spacer(Modifier.height(12.dp))
        if (interactive) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                FocusChip("Idioma") { onAudio() }
                FocusChip("Subtítulos") { onSubs() }
                FocusChip("Velocidad: $speedLabel") { onSpeed() }
                FocusChip("Pantalla: $aspectLabel") { onAspect() }
                FocusChip(if (isFav) "Quitar de ★" else "Agregar a ★") { onFav() }
            }
        } else {
            Text(
                "Izquierda / Derecha: moverte en el tiempo  ·  OK: pausa  ·  Abajo: idioma, subtítulos y más  ·  Atrás: miniatura",
                fontSize = 15.sp, color = Gray, maxLines = 1
            )
        }
    }
}

@Composable
private fun PosterCard(item: PosterItem, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.08f else 1f)
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .width(150.dp)
            .height(225.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(Th.theme.card2)
            .then(if (focused) Modifier.border(3.dp, Color.White, shape) else Modifier)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
    ) {
        if (!item.logo.isNullOrBlank()) {
            AsyncImage(
                model = item.logo,
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE000000))))
                .padding(horizontal = 8.dp, vertical = 8.dp)
        ) {
            Text(item.name, fontSize = 14.sp, maxLines = 2, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun SectionsStrip(
    movieCount: Int,
    seriesCount: Int,
    secFocus: FocusRequester,
    onTv: () -> Unit,
    onMovies: () -> Unit,
    onSeries: () -> Unit,
    onRight: () -> Unit
) {
    Column(
        Modifier
            .fillMaxHeight()
            .padding(end = 20.dp)
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (e.key) {
                    Key.DirectionRight -> { onRight(); true }
                    Key.DirectionLeft -> true
                    else -> false
                }
            },
        verticalArrangement = Arrangement.spacedBy(32.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        QuickButton(null, "TV", Modifier.focusRequester(secFocus), draw = { c -> drawTv(c) }, onClick = onTv)
        if (movieCount > 0) QuickButton(null, "Películas", draw = { c -> drawFilm(c) }, onClick = onMovies)
        if (seriesCount > 0) QuickButton(null, "Series", draw = { c -> drawSeries(c) }, onClick = onSeries)
    }
}

// Pantalla de catálogo estilo Netflix: filas por categoría con carátulas.
// Izquierda (en la primera carátula) muestra el menú de TV / Películas / Series.
@Composable
private fun PosterBrowser(
    title: String,
    rows: List<Pair<String, List<PosterItem>>>,
    pip: Boolean,
    pipH: Dp,
    movieCount: Int,
    seriesCount: Int,
    onTv: () -> Unit,
    onMovies: () -> Unit,
    onSeries: () -> Unit,
    onSearch: () -> Unit,
    onPick: (Int, Int) -> Unit
) {
    val first = remember { FocusRequester() }
    val secFocus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var showStrip by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { first.requestFocus() }
    }
    LaunchedEffect(showStrip) {
        if (showStrip) {
            repeat(4) {
                if (runCatching { secFocus.requestFocus() }.isSuccess) return@LaunchedEffect
                delay(60)
            }
        }
    }
    Row(
        Modifier
            .fillMaxSize()
            .background(bg(0.96f))
            .padding(start = 24.dp, end = 16.dp, top = 20.dp)
    ) {
        AnimatedVisibility(
            visible = showStrip,
            enter = fadeIn() + expandHorizontally(),
            exit = fadeOut() + shrinkHorizontally()
        ) {
            SectionsStrip(
                movieCount, seriesCount, secFocus, onTv, onMovies, onSeries,
                onRight = { showStrip = false; runCatching { first.requestFocus() } }
            )
        }
        Column(
            Modifier
                .weight(1f)
                .fillMaxHeight()
                .onPreviewKeyEvent { e ->
                    if (e.type == KeyEventType.KeyDown && e.key == Key.DirectionLeft) {
                        if (!focusManager.moveFocus(FocusDirection.Left)) showStrip = true
                        true
                    } else false
                }
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppLogo(44.dp)
                Spacer(Modifier.width(14.dp))
                Text(title, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(28.dp))
                FocusChip("Buscar") { onSearch() }
            }
            // Con la película en miniatura, el catálogo empieza debajo de ella
            if (pip) Spacer(Modifier.height(pipH - 40.dp))
            Spacer(Modifier.height(8.dp))
            if (rows.isEmpty()) {
                Text("No hay contenido.", fontSize = 20.sp, color = Gray, modifier = Modifier.padding(8.dp))
            }
            LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(rows) { r, row ->
                    Text(
                        "${row.first}  (${row.second.size})",
                        fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                        modifier = Modifier.padding(top = 14.dp, bottom = 8.dp, start = 4.dp)
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                    ) {
                        itemsIndexed(row.second) { i, item ->
                            PosterCard(
                                item,
                                if (r == 0 && i == 0) Modifier.focusRequester(first) else Modifier
                            ) { onPick(r, i) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EpisodesPanel(
    modifier: Modifier,
    show: Show,
    favs: Set<String>,
    onToggleFav: (Channel) -> Unit,
    onBack: () -> Unit,
    onPick: (List<Channel>, Int) -> Unit
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    SidePanel(
        modifier.onPreviewKeyEvent { e ->
            if (e.type == KeyEventType.KeyDown && e.key == Key.DirectionLeft) { onBack(); true } else false
        },
        760.dp
    ) {
        PanelTitle(show.title)
        LazyColumn {
            itemsIndexed(show.episodes) { i, ch ->
                ChannelRow(
                    ch, ch.url in favs,
                    if (i == 0) Modifier.focusRequester(focus) else Modifier,
                    { onToggleFav(ch) }
                ) { onPick(show.episodes, i) }
            }
        }
    }
}

@Composable
private fun VodTracksPanel(
    modifier: Modifier,
    player: Player,
    tick: Int,
    kind: Int,
    onAudio: (Tracks.Group, Int) -> Unit,
    onSubOff: () -> Unit,
    onSub: (Tracks.Group, Int) -> Unit
) {
    val groups = remember(tick) { player.currentTracks.groups }
    val audio = groups.filter { it.type == C.TRACK_TYPE_AUDIO }
    val texts = groups.filter { it.type == C.TRACK_TYPE_TEXT }
    val textOn = texts.any { it.isSelected }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    var row = 0
    Column(
        modifier
            .fillMaxHeight()
            .width(460.dp)
            .background(bg(0.94f))
            .padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        PanelTitle(if (kind == 0) "Idioma" else "Subtítulos")
        if (kind == 0) {
            if (audio.isEmpty()) Text("Esta película no trae pistas de audio", fontSize = 16.sp, color = Gray, modifier = Modifier.padding(start = 8.dp))
            var n = 0
            audio.forEach { g ->
                for (i in 0 until g.length) {
                    n++
                    val label = trackLabel(g.getTrackFormat(i), n)
                    FocusRow(if (row++ == 0) Modifier.focusRequester(focus) else Modifier, onClick = { onAudio(g, i) }) {
                        Text(label, fontSize = 20.sp, modifier = Modifier.weight(1f), maxLines = 1)
                        if (g.isTrackSelected(i)) Text("✓", fontSize = 20.sp, color = Gold)
                    }
                }
            }
        } else {
            FocusRow(Modifier.focusRequester(focus), onClick = onSubOff) {
                Text("Desactivados", fontSize = 20.sp, modifier = Modifier.weight(1f))
                if (!textOn) Text("✓", fontSize = 20.sp, color = Gold)
            }
            if (texts.isEmpty()) Text("Esta película no trae subtítulos", fontSize = 16.sp, color = Gray, modifier = Modifier.padding(start = 8.dp, top = 8.dp))
            var m = 0
            texts.forEach { g ->
                for (i in 0 until g.length) {
                    m++
                    val label = trackLabel(g.getTrackFormat(i), m)
                    FocusRow(onClick = { onSub(g, i) }) {
                        Text(label, fontSize = 20.sp, modifier = Modifier.weight(1f), maxLines = 1)
                        if (g.isTrackSelected(i)) Text("✓", fontSize = 20.sp, color = Gold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ListsPanel(
    modifier: Modifier,
    lists: List<Pair<String, String>>,
    activeUrl: String,
    onSelect: (String) -> Unit,
    onDelete: (Int) -> Unit,
    onAdd: (String, String) -> Unit
) {
    val focus = remember { FocusRequester() }
    var name by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    SidePanel(modifier, 880.dp) {
        PanelTitle("Mis listas")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            lists.forEachIndexed { i, (n, u) ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    FocusRow(
                        Modifier.weight(1f).then(if (i == 0) Modifier.focusRequester(focus) else Modifier),
                        onClick = { onSelect(u) }
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(n, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(hostOf(u), fontSize = 15.sp, color = Gray, maxLines = 1)
                        }
                        if (u == activeUrl) Text("✓ en uso", fontSize = 18.sp, color = Gold)
                    }
                    Spacer(Modifier.width(8.dp))
                    FocusChip("Borrar") { onDelete(i) }
                }
            }
            if (lists.isEmpty()) {
                Text("Aún no hay listas guardadas.", fontSize = 18.sp, color = Gray, modifier = Modifier.padding(8.dp))
            }
            Spacer(Modifier.height(16.dp))
            Text("Agregar lista nueva", fontSize = 20.sp, color = Gold, modifier = Modifier.padding(start = 8.dp, bottom = 6.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nombre (opcional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = link,
                onValueChange = { link = it },
                label = { Text("URL de la lista M3U") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
            )
            Spacer(Modifier.height(10.dp))
            Row(Modifier.padding(start = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FocusChip("Agregar y cargar") { if (link.isNotBlank()) { onAdd(name.trim(), link.trim()); name = ""; link = "" } }
                FocusChip("Limpiar") { name = ""; link = "" }
            }
        }
    }
}

@Composable
private fun SettingRow(label: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit, swatch: Brush? = null) {
    FocusRow(modifier, onClick) {
        if (swatch != null) {
            Box(Modifier.padding(end = 14.dp).size(26.dp).clip(RoundedCornerShape(50)).background(swatch).border(2.dp, Color(0x66FFFFFF), RoundedCornerShape(50)))
        }
        Text(label, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (value.isNotEmpty()) Text(value, fontSize = 18.sp, color = Gray, maxLines = 3, modifier = Modifier.widthIn(max = 380.dp))
    }
}

// ---------------- Componentes ----------------

@Composable
private fun FocusChip(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.08f else 1f)
    val bg: Brush = if (focused) AccentBrush else SolidColor(Color(0x33FFFFFF))
    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(50))
            .background(bg)
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) { Text(text, fontSize = 18.sp, color = Color.White) }
}

@Composable
private fun FocusRow(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onLongPress: (() -> Unit)? = null,
    onFocusIn: (() -> Unit)? = null,
    highlight: Boolean = false,
    content: @Composable RowScope.(Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    var longDone by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.02f else 1f)
    val shape = RoundedCornerShape(40.dp)
    val bg: Brush = when {
        focused -> AccentBrush
        highlight -> SolidColor(Color(0x40FFFFFF))
        else -> SolidColor(Color(0x14FFFFFF))
    }
    Row(
        modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                transformOrigin = TransformOrigin(0f, 0.5f)
            }
            .clip(shape)
            .background(bg)
            .then(if (focused) Modifier.border(2.dp, Color(0x66FFFFFF), shape) else Modifier)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocusIn?.invoke()
            }
            .onPreviewKeyEvent { e ->
                if (onLongPress == null) return@onPreviewKeyEvent false
                val ok = e.key == Key.DirectionCenter || e.key == Key.Enter
                if (!ok) return@onPreviewKeyEvent false
                when (e.type) {
                    KeyEventType.KeyDown ->
                        if (e.nativeKeyEvent.repeatCount > 0) {
                            if (!longDone) { longDone = true; onLongPress() }
                            true
                        } else false
                    KeyEventType.KeyUp ->
                        if (longDone) { longDone = false; true } else false
                    else -> false
                }
            }
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) { this.content(focused) }
}

@Composable
private fun ChannelRow(
    ch: Channel,
    fav: Boolean,
    modifier: Modifier = Modifier,
    onLong: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    FocusRow(modifier, onClick, onLong) {
        Logo(ch.logo, 60.dp, ch.name)
        Spacer(Modifier.width(20.dp))
        Column(Modifier.weight(1f)) {
            Text(ch.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("Sin información", fontSize = 18.sp, color = Gray, maxLines = 1)
        }
        if (fav) {
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.Star, contentDescription = "Favorito", tint = Gold, modifier = Modifier.size(28.dp))
        }
    }
}

@Composable
fun Clock(modifier: Modifier = Modifier) {
    val fmt = remember { SimpleDateFormat("hh:mm a - EEE, d MMM yyyy", Locale("es", "MX")) }
    var now by remember { mutableStateOf(fmt.format(Date())) }
    LaunchedEffect(Unit) {
        while (true) { now = fmt.format(Date()); delay(15000) }
    }
    Pill(now, modifier, 22.sp)
}

@Composable
fun Pill(text: String, modifier: Modifier = Modifier, size: TextUnit = 18.sp) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0x99000000))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(50))
            .padding(horizontal = 18.dp, vertical = 8.dp)
    ) { Text(text, fontSize = size, color = Color.White) }
}

@Composable
fun Logo(url: String?, size: Dp, name: String? = null) {
    val shape = RoundedCornerShape(size / 6)
    val ctx = LocalContext.current
    var attempt by remember(url) { mutableIntStateOf(0) }
    var failed by remember(url) { mutableStateOf(false) }
    // Si un logo falla, se reintenta solo hasta 3 veces con pausa creciente
    LaunchedEffect(failed, url) {
        if (failed && attempt < 5) {
            delay(1200L * (attempt + 1))
            attempt += 1
            failed = false
        }
    }
    Box(
        Modifier
            .size(size)
            .clip(shape)
            .background(Color.White)
            .border(1.dp, Color(0x33FFFFFF), shape)
            .padding(size / 14),
        contentAlignment = Alignment.Center
    ) {
        if (url.isNullOrBlank() || (failed && attempt >= 5)) {
            val ini = name?.replace(Regex("^[^\\p{L}\\p{N}]+"), "")?.replace(Regex("(?i)^24/7\\s*"), "")?.trim()?.split(" ")?.filter { it.isNotEmpty() }?.take(2)?.joinToString("") { it.first().uppercase() }?.takeIf { it.isNotEmpty() } ?: "TV"
            Text(ini, fontSize = (size.value / 3).sp, fontWeight = FontWeight.Bold, color = Color(0xFF9AA3B5))
        } else {
            val req = remember(url, attempt) {
                ImageRequest.Builder(ctx)
                    .data(url.trim().replace(" ", "%20"))
                    .setParameter("retry", attempt, memoryCacheKey = null)
                    .listener(
                        onError = { r, res ->
                            failed = true
                            LogoDiag.fails += 1
                            LogoDiag.last = (res.throwable.message ?: res.throwable.javaClass.simpleName) + " → " + r.data.toString().take(70)
                        },
                        onSuccess = { _, _ -> failed = false }
                    )
                    .build()
            }
            AsyncImage(
                model = req,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
fun PlayerOverlay(ch: Channel, res: String, fav: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.Transparent, bg(0.95f))))
            .padding(horizontal = 36.dp, vertical = 28.dp)
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Logo(ch.logo, 116.dp, ch.name)
            Spacer(Modifier.width(26.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ch.number?.let {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(AccentBrush)
                                .padding(horizontal = 12.dp, vertical = 3.dp)
                        ) { Text(it, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp))
                    }
                    Text(
                        "${ch.group} • ${ch.name}",
                        fontSize = 22.sp, color = Gray, fontWeight = FontWeight.Bold, maxLines = 1
                    )
                }
                Text("Sin información", fontSize = 38.sp, fontWeight = FontWeight.Medium)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (fav) Icon(Icons.Default.Star, contentDescription = "Favorito", tint = Gold, modifier = Modifier.size(32.dp))
                if (res.isNotEmpty()) Pill(res)
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0x33FF4D4D))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(Red))
                    Spacer(Modifier.width(8.dp))
                    Text("EN VIVO", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}
